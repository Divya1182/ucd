package com.cigna.s3.intentartifact.config;

import software.amazon.awssdk.services.rdsdata.RdsDataClient;
import software.amazon.awssdk.regions.Region;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;


    @Configuration
    public class AwsConfig {

        @Bean
        public RdsDataClient rdsDataClient() {
            return RdsDataClient.builder()
                    .region((Region.of(System.getenv("AWS_REGION"))))
                    .credentialsProvider(DefaultCredentialsProvider.create())
                    .build();
        }
}
