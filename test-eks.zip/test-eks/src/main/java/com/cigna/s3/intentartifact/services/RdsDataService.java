package com.cigna.s3.intentartifact.services;

import software.amazon.awssdk.services.rdsdata.RdsDataClient;
import software.amazon.awssdk.services.rdsdata.model.ExecuteStatementRequest;
import software.amazon.awssdk.services.rdsdata.model.ExecuteStatementResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class RdsDataService {

    @Value("${aws.rds.resource-arn}")
    private String resourceArn;

    @Value("${aws.rds.secret-arn}")
    private String secretArn;

    @Value("${aws.rds.database}")
    private String database;

    private final RdsDataClient rdsDataClient;
    private final Logger logger = LoggerFactory.getLogger(RdsDataService.class);

    public RdsDataService(RdsDataClient rdsDataClient) {
        this.rdsDataClient = rdsDataClient;
    }

    public String executeQuery() {
       // logger.info("Getting service name: " + rdsDataClient.serviceName());
        ExecuteStatementRequest request = ExecuteStatementRequest.builder()
                .resourceArn(resourceArn).secretArn(secretArn).database(database)
                .sql("SELECT TO_CHAR(NOW(), 'MM-DD-YYYY HH24:MI:SS')")
                .build();

        ExecuteStatementResponse response = rdsDataClient.executeStatement(request);
        return response.formattedRecords();
    }
}
