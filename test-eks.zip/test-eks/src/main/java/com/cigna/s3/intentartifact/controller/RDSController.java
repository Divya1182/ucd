package com.cigna.s3.intentartifact.controller;

import com.cigna.s3.intentartifact.services.RdsDataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/evernorth/v2/intents/testeks")
public class RDSController {

    private final RdsDataService rdsDataService;
    private final Logger logger = LoggerFactory.getLogger(RDSController.class);

    @Autowired
    public RDSController(RdsDataService rdsDataService) {
        this.rdsDataService = rdsDataService;
    }

    @GetMapping(path = "/rds/check")
    public ResponseEntity<String> testRds() {
        return ResponseEntity.status(HttpStatus.OK).body(rdsDataService.executeQuery());
    }

}