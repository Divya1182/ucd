//package com.cigna.s3.intentartifact.model;
//
//import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//import java.io.Serializable;
//
//@Entity
//@Data
//@JsonIgnoreProperties
//@AllArgsConstructor
//@NoArgsConstructor
//@Table(schema = "phbb_db", name = "pharmacy_benefit_test")
//public class PharmacyBenefit implements Serializable {
//    @Id
//    @Column(name="pharmacy_id", nullable = false)
//    private int pharmacyId;
//
//    @Column(name="pharmacy_name")
//    private String pharmacyName;
//
//    @Column(name="pharmacy_type")
//    private String pharmacyType;
//}
