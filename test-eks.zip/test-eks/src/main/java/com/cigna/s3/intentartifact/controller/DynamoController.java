package com.cigna.s3.intentartifact.controller;

import com.cigna.s3.intentartifact.services.DynamoDbService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

import java.util.Map;

@RestController
@RequestMapping(value = "/evernorth/v2/intents/testeks")
public class DynamoController {
    private final Logger logger = LoggerFactory.getLogger(DynamoController.class);
    private DynamoDbService dynamoDbService;

    @Autowired
    public DynamoController(DynamoDbService dynamoDbService) {
        this.dynamoDbService = dynamoDbService;
    }

    @GetMapping(path = "/dynamo/item")
    public ResponseEntity<?> getDynamoItem(@RequestParam String id) {
        try {
            Map<String, String> item = dynamoDbService.getItemById(id);
            if (item == null || item.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Item not found for id: " + id);
            }

            ObjectMapper mapper = new ObjectMapper();
            String json = mapper.writeValueAsString(item);

            return ResponseEntity.ok(json);
        } catch (Exception e) {
            logger.error("Error fetching item from DynamoDB", e);
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to fetch item.");
        }
    }

}