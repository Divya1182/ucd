//package com.cigna.s3.intentartifact.repository;
//
//import com.cigna.s3.intentartifact.model.PharmacyBenefit;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository
//public interface PharmacyBenefitRepository extends JpaRepository<PharmacyBenefit,Integer> {
//
//    List<PharmacyBenefit> findAll();
//}
