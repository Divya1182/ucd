package com.cigna.s3.intentartifact.dto;

import lombok.Data;

@Data
public class PharmacyBenefitRequest {
    private int pharmacyId;
    private String pharmacyName;
    private String pharmacyType;
}
