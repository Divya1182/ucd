'use strict';
exports.handler = (event, context, callback) => {

    const request = event.Records[0].cf.request;
    const response = event.Records[0].cf.response;
    const headers = response.headers;
    const contentTypeHeader = headers['content-type'];
    const contentType = contentTypeHeader !== undefined && contentTypeHeader.length > 0 ?
        contentTypeHeader[0].value : 'text/plain';

    // Set new headers
    headers['strict-transport-security'] = [{
        key: 'Strict-Transport-Security',
        value: 'max-age=${strict_transport_security_max_age}; includeSubdomains; preload'
    }];
    headers['content-security-policy'] = [{
        key: 'Content-Security-Policy',
        value: "${content_security_policy_value}"
    }];
    headers['x-content-type-options'] = [{key: 'X-Content-Type-Options', value: 'nosniff'}];
    headers['x-frame-options'] = [{key: 'X-Frame-Options', value: 'DENY'}];
    headers['x-xss-protection'] = [{key: 'X-XSS-Protection', value: '1; mode=block'}];
    headers['referrer-policy'] = [{key: 'Referrer-Policy', value: 'same-origin'}];
    headers['vary'] = [{key: 'Vary', value: 'Origin,Access-Control-Request-Headers,Access-Control-Request-Method'}];
    if (request.method === "OPTIONS") {
        if ("${add_cors_allow_credentials}" === "true") {
            headers['access-control-allow-credentials'] = [{key: 'Access-Control-Allow-Credentials', value: 'true'}];
        }
        headers['cache-control'] = [{key: 'Cache-Control', value: "${cache_control_default}"}];
    } else {
        // Cache control added here instead of per S3 object
        if (contentType.startsWith('image/') || contentType.startsWith('audio/') || contentType.startsWith('video/')) {
            headers['cache-control'] = [{key: 'Cache-Control', value: "${cache_control_images}"}];
        } else if (contentType.startsWith('font/')) {
            headers['cache-control'] = [{key: 'Cache-Control', value: "${cache_control_fonts}"}];
        } else if (contentType === 'text/css') {
            headers['cache-control'] = [{key: 'Cache-Control', value: "${cache_control_css}"}];
        } else {
            headers['cache-control'] = [{key: 'Cache-Control', value: "${cache_control_default}"}];
        }
    }

    if (request.uri.indexOf('index.html') !== -1) {
        headers['content-type'] = [{
            key: 'Content-Type',
            value: ' text/html; charset=utf-8'
        }];
    }
    // Return modified response with just headers
      callback(null, response);
};
