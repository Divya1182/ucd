var {S3Client, GetObjectCommand, PutObjectCommand} = require("@aws-sdk/client-s3");
var {SSM} = require("@aws-sdk/client-ssm");
var ssm = new SSM();
var s3 = new S3Client({apiVersion: '2006-03-01'});
let doInsertRecursion = false

exports.handler = async (event) => {
    try {
        // Fetches a SSM parameter whose path is passed in
        const ssmParam = event.source === 'aws.ssm' ?  event.detail.name.toString() : process.env.SSM_BASE_PATHS.split(",")[0];
        const ssmPath = ssmParam.substring(0, ssmParam.lastIndexOf("/") + 1);
        const ssiData = await getSSMValuesByPath(ssmPath);
        const ssmParamPathArray = ssmParam.split("/")
        const appName = ssmParamPathArray[ssmParamPathArray.length - 3];
        const rootVarName = ssmParamPathArray[ssmParamPathArray.length - 2];
        const myMap = new Map();
        ssiData.forEach(function (ssi) {
            const pName = ssi.Name;
            const lastIndex = pName.lastIndexOf("/")
            const paramName = (pName.substring(lastIndex + 1));
            myMap.set(paramName, ssi.Value);
        });

        const rootMap = new Map()
        rootMap.set(rootVarName, Object.fromEntries(myMap));
        const jsonObj = Object.fromEntries(rootMap);
        const jsonString = JSON.stringify(jsonObj);
        const s3ObjectKey = GetPropertyValue(process.env, appName + "_" + "OBJECT_KEY")
        var s3Params = {
            Bucket: process.env.BUCKET_NAME,
            Key: s3ObjectKey
        };
        const s3Body = await getObject(s3Params);
        const updatedHtml = processSsi(s3Body, jsonString, ssmParam);
        doInsertRecursion = false;
        let contentType = "text/html"
        const s3PutParams = {
            Bucket: process.env.BUCKET_NAME,
            Key: s3ObjectKey,
            Body: updatedHtml,
            ContentType: contentType
        }
        const putCommand = new PutObjectCommand(s3PutParams);
        await s3.send(putCommand);
    } catch (e) {
        console.log('lambda handler failed with exception : ' + e)
    }
};

function GetPropertyValue(obj, dataToRetrieve) {
    return dataToRetrieve
        .split('.') // split string based on `.`
        .reduce(function (o, k) {
            return o && o[k]; // get inner property if `o` is defined else get `o` and return
        }, obj) // set initial value as object
}

async function getObject(params) {
    try {
        /* code */
        const streamToString = (stream) =>
            new Promise((resolve, reject) => {
                const chunks = [];
                stream.on("data", (chunk) => chunks.push(chunk));
                stream.on("error", reject);
                stream.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
            });
        const command = new GetObjectCommand(params);
        const {Body: s3objectBody} = await s3.send(command);
        const bodyContents = await streamToString(s3objectBody);
        if (bodyContents === undefined) {
            console.log('received no data from stream')
        }
        return bodyContents;
    } catch (e) {
        console.log('error with getObject ' + e);
        return null;
    }
}

function getSSMValuesByPath(path, memo = [], nextToken) {
    return ssm
        .getParametersByPath({Path: path, WithDecryption: true, Recursive: true, NextToken: nextToken, MaxResults: 10})
        .then(({Parameters, NextToken}) => {
            const newMemo = memo.concat(Parameters);
            return NextToken ? getSSMValuesByPath(path, newMemo, NextToken) : newMemo;
        });
}

function processSsi(data, ssiMapping, ssmParam) {
    const pArray = ssmParam.split("/");
    const ssmParamKey = pArray[pArray.length - 2];
    const ssiRe = "<!--# echo var=\"" + ssmParamKey + "\"" + "\\s+" + ".*?" + "\\s?" + "-->"
    let index = -1
    const ssiMatch = data.match(ssiRe)
    if (ssiMatch != null) {
        index = data.indexOf(ssiMatch[0])
    }
    const updtStrRegx = "='{&quot;" + ssmParamKey + "&quot;\s*:\s*";
    const updtSsiRe = new RegExp(updtStrRegx);
    let updatedIndex = -1
    const updtMatch = data.match(updtSsiRe)
    if (updtMatch != null && !doInsertRecursion) {
        updatedIndex = data.indexOf(updtMatch[0])
    }
    if (index !== -1) {
        let endIndex = data.indexOf('-->', index);
        if (endIndex !== -1) {
            endIndex += 3;
            const front = data.slice(0, index);
            const rear = data.slice(endIndex);
            const ssi = data.slice(index, endIndex);
            const matches = ssi.match(ssiRe);
            let ssiValue = 'PLACEHOLDER';
            if (matches !== null) {
                const key = matches[0];
                if (key.indexOf(ssmParamKey) != -1) {
                    const mapObj = JSON.parse(ssiMapping);
                    ssiValue = mapObj[key];
                    data = front + htmlEncode(ssiMapping) + rear;
                }
            }
            doInsertRecursion = true
            data = processSsi(data, ssiMapping, ssmParam);
        }
    } else if (updatedIndex !== -1) {
        let upendIndex = data.indexOf('\'/>', updatedIndex)
        if (upendIndex == -1) {
            upendIndex = data.indexOf('>', updatedIndex);
            upendIndex += 2;
        } else
            upendIndex += 3;
        if (upendIndex !== -1) {
            const updfront = data.slice(0, updatedIndex);
            let updrear = data.slice(upendIndex);
            updrear = updrear.trimLeft();
            const updssi = data.slice(updatedIndex, upendIndex);
            const updtMatch = updssi.match(updtSsiRe);
            if ((updtMatch !== null)) {
                data = updfront + "='" + htmlEncode(htmlDecode(ssiMapping)) + '\'/>' + processSsi(updrear, ssiMapping, ssmParam);
            }
        }
    }
    return data;
}


function htmlEncode(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}


function htmlDecode(str) {
    return String(str).replace('&amp;', /&/g).replace('&lt;', /</g).replace('&gt;', />/g).replace('&quot;', /"/g);
}

