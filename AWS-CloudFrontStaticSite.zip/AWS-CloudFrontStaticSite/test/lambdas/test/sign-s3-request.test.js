const {test} = require('@jest/globals');
const ssr = require('../src/sign-s3-request');
const event = require('./demo-spa-request-event.json')

test('creates AWS v4 signature for valid request', () => {
    const signedReq = await ssr.handler(event);
    expect(signedReq);
});
