module.exports = {
    rootDir: "test",
    transform: {
        "^.+\\.(j|t)sx?$": "babel-jest",
    }
};