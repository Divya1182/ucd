package main

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/logger"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
	// "gopkg.in/ini.v1"
)

// # Re-enable once edge lambdas are disassociated during destroy
//
// func getBackendConfig() (cfg map[string]interface{}) {
// 	var backendCfg, _ = ini.InsensitiveLoad("../examples/envs/dev/backend.config")
// 	var section = backendCfg.Section("")
// 	return map[string]interface{}{
// 		"bucket": section.Key("bucket").String(),
// 		"key": section.Key("key").String(),
// 		"dynamodb_table": section.Key("dynamodb_table").String(),
// 		"region": section.Key("region").String(),
// 	}
// }

func getVars(t *testing.T) (vars map[string]interface{}) {
	terraform.GetAllVariablesFromVarFile(t, "../examples/envs/dev/dev.tfvars", &vars)
	return
}

func TestTerraformModuleWithDefaults(t *testing.T) {
	terraformOptions := &terraform.Options{
		TerraformDir: "../examples/main",
		// BackendConfig: getBackendConfig(),
		Vars: getVars(t),
		SetVarsAfterVarFiles: true,
		Upgrade: true,
		Reconfigure: true,
		Logger: logger.Discard,
	}

	planOut := terraform.InitAndPlan(t, terraformOptions)

	rscCount := terraform.GetResourceCount(t, planOut)
	assert.Equal(t, 90, rscCount.Add)
}

func TestTerraformModuleWithMinResources(t *testing.T) {
	terraformOptions := &terraform.Options{
		TerraformDir: "../examples/min-resources",
		// BackendConfig: getBackendConfig(),
		Vars: getVars(t),
		SetVarsAfterVarFiles: true,
		Upgrade: true,
		Reconfigure: true,
		Logger: logger.Discard,
	}

	planOut := terraform.InitAndPlan(t, terraformOptions)

	rscCount := terraform.GetResourceCount(t, planOut)
	assert.Equal(t, 76, rscCount.Add)

	// terraform.Destroy(t, terraformOptions)
}

func TestTerraformModuleWithAllResources(t *testing.T) {
	terraformOptions := &terraform.Options{
		TerraformDir: "../examples/all-resources",
		// BackendConfig: getBackendConfig(),
		Vars: getVars(t),
		SetVarsAfterVarFiles: true,
		Upgrade: true,
		Reconfigure: true,
		Logger: logger.Discard,
	}

	planOut := terraform.InitAndPlan(t, terraformOptions)

	rscCount := terraform.GetResourceCount(t, planOut)
	assert.Equal(t, 70, rscCount.Add)

	// terraform.Destroy(t, terraformOptions)
}

func TestTerraformModuleWithCreateLogBucketSet(t *testing.T) {
	terraformOptions := &terraform.Options{
		TerraformDir: "../examples/with-logbucket",
		// BackendConfig: getBackendConfig(),
		Vars: getVars(t),
		SetVarsAfterVarFiles: true,
		Upgrade: true,
		Reconfigure: true,
		Logger: logger.Discard,
	}

	planOut := terraform.InitAndPlan(t, terraformOptions)

	rscCount := terraform.GetResourceCount(t, planOut)
	assert.Equal(t, 84, rscCount.Add)

	// terraform.Destroy(t, terraformOptions)
}

func TestTerraformModuleWithCustomOrigin(t *testing.T) {
	terraformOptions := &terraform.Options{
		TerraformDir: "../examples/custom-origin",
		// BackendConfig: getBackendConfig(),
		Vars: getVars(t),
		SetVarsAfterVarFiles: true,
		Upgrade: true,
		Reconfigure: true,
		Logger: logger.Discard,
	}

	planOut := terraform.InitAndPlan(t, terraformOptions)

	rscCount := terraform.GetResourceCount(t, planOut)
	assert.Equal(t, 46, rscCount.Add)

	// terraform.Destroy(t, terraformOptions)
}
