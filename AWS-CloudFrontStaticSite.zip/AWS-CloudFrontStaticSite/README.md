# AWS-CloudFrontStaticSite

Terraform module for creating infrastructure to serve a single-page app.

## Overview

Provides AWS infrastructure for deploying a static-content-only, single-page app (SPA) the Health Services way.
Content is stored in an S3 bucket and served by CloudFront using a PKI certificate signed by AWS Certificate
Manager and DNS handled by Route 53. Access logs are forwarded to a centralized log bucket maintained by the
enterprise infrastructure team. CloudWatch alerts are forwarded to a centralized SNS topic.

## Dependencies

* Terraform version `1.2` or higher is required for this module to work.
* Terraform provider `hashicorp\aws` version `4.41.0` or higher is required.

## Building and Deploying Locally

Building in this case is initializing the terraform project and caching the results. This step will only have to happen
once across many builds unless any of the inputs change. The infrastructure is built and deployed using the **please**
build tool, which can be run be executing `plz <command> <target>` or by using the built-in wrapper
`./pleasew <command> <target>`. The **--show_all_output** flag indicates to the **please** build tool that it should
ignore its own output formatting and just show the standard out messages.

### Required Environment Variables

| Var Name          | Var Value                            | Reason                                                                                                      |
|-------------------|--------------------------------------|-------------------------------------------------------------------------------------------------------------|
| AWS_FED_PASSWORD  | your aws console password            | used by aws-fed to login to the environment (requires id has admin access to provision, read only for plan) |
| AWS_FED_USERNAME  | your aws User Name                   | used by aws-fed to login to the environment (requires id has admin access to provision, read only for plan) |


### Local-only configuration

Create file **env.list** that sources the required env vars. This file is already added to the **.gitignore** file
Create file **.plzconfig.local** that changes please configuration for the local environment. This file is already
added to the **.gitignore** file. For the `core-ingestion` project to build a local backend configuration and a
local vars file in `env-config` are also required. Please see the associated README for that project for more detailed
information.

The contents of the **.plzconfig.local** file should look like the following but relevant to your local setup:

```ini
[buildconfig]
app-instance = my-feature
```

It is highly recommended that all builds are done via the Jenkins Agent Docker container that is setup for this build.
It will ensure that builds are executed the same across developer machines and setups, and that builds will execute
the same locally vs on the Jenkins server. If you try to call `please` directly from the command-line you are on your
own to figure out why it does not work properly :).

The please build terraform container: https://quay.sys.cigna.com/repository/imdevops/jenkins-generic-agent
**Docker Command**
```bash
docker run -it --rm --entrypoint="" --name <component_name>-build -t --env-file env.list -w /opt/devops/jenkins/workspace/<component_name> -v $(pwd):/opt/devops/jenkins/workspace/<component_name>:rw,z quay.sys.cigna.com/imdevops/jenkins-generic-agent:<version> /bin/bash
```


**Example**
```bash
$ docker run -it --rm --entrypoint="" --name terraform_plz -t --env-file env.list -w /opt/devops/jenkins/workspace/cds -v $(pwd):/opt/devops/jenkins/workspace/cds:rw,z quay.sys.cigna.com/imdevops/jenkins-generic-agent:0.0.32 /bin/bash`
# Cleans out Build Cache does not need to be run everytime
plz clean
# Federate for local
plz fed local
# Test Everything for Module
plz test //... -i unit --show_all_output
# Lints Everything for Module
plz build //... -i lint --show_all_output
```

## CICD Documention

For additional info on the build process and pipeline

Road to Production: https://confluence.sys.cigna.com/display/cloudeng/Roadmap+to+AWS+Production#RoadmaptoAWSProduction-AutoSetup
Build Tool: https://confluence.sys.cigna.com/display/cloudeng/Cloud+Build+Tool
Jenkins: https://confluence.sys.cigna.com/display/cloudeng/Jenkins+Cloud+Architecture

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.2.0, < 2.0.0 |
| <a name="requirement_archive"></a> [archive](#requirement\_archive) | ~> 2.1 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.41.0, < 6.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 4.41.0, < 6.0.0 |
| <a name="provider_aws.failover"></a> [aws.failover](#provider\_aws.failover) | >= 4.41.0, < 6.0.0 |
| <a name="provider_aws.primary"></a> [aws.primary](#provider\_aws.primary) | >= 4.41.0, < 6.0.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_centralized_logs"></a> [centralized\_logs](#module\_centralized\_logs) | ./cloudwatch-centralized | n/a |
| <a name="module_kms_key_failover"></a> [kms\_key\_failover](#module\_kms\_key\_failover) | ./kms | n/a |
| <a name="module_kms_key_primary"></a> [kms\_key\_primary](#module\_kms\_key\_primary) | ./kms | n/a |
| <a name="module_kms_key_primary_ssm_store"></a> [kms\_key\_primary\_ssm\_store](#module\_kms\_key\_primary\_ssm\_store) | ./kms | n/a |
| <a name="module_log_bucket"></a> [log\_bucket](#module\_log\_bucket) | ./logbucket | n/a |
| <a name="module_origin_request_lambda"></a> [origin\_request\_lambda](#module\_origin\_request\_lambda) | ./edgelambda | n/a |
| <a name="module_origin_response_lambda"></a> [origin\_response\_lambda](#module\_origin\_response\_lambda) | ./edgelambda | n/a |
| <a name="module_trigger_lambda"></a> [trigger\_lambda](#module\_trigger\_lambda) | ./triggerlambda | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_acm_certificate.aws_evernorthcloud_cert](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/acm_certificate) | resource |
| [aws_acm_certificate.custom_domain_cert](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/acm_certificate) | resource |
| [aws_acm_certificate.site_cert](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/acm_certificate) | resource |
| [aws_acm_certificate.wildcard_cert](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/acm_certificate) | resource |
| [aws_acm_certificate_validation.aws_evernorthcloud_domain_cert_validation](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/acm_certificate_validation) | resource |
| [aws_acm_certificate_validation.custom_domain_cert_validation](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/acm_certificate_validation) | resource |
| [aws_acm_certificate_validation.site_cert_validation](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/acm_certificate_validation) | resource |
| [aws_acm_certificate_validation.wildcard_cert_validation](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/acm_certificate_validation) | resource |
| [aws_cloudfront_cache_policy.site_cache_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_cache_policy) | resource |
| [aws_cloudfront_distribution.site](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_distribution) | resource |
| [aws_cloudfront_monitoring_subscription.subscription](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_monitoring_subscription) | resource |
| [aws_cloudfront_origin_access_control.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_origin_access_control) | resource |
| [aws_cloudfront_origin_access_control.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudfront_origin_access_control) | resource |
| [aws_cloudwatch_event_rule.s3Upload_ssi_notification](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_rule) | resource |
| [aws_cloudwatch_event_rule.ssiparam_notification](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_rule) | resource |
| [aws_cloudwatch_event_rule.ssiparam_notification_v2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_rule) | resource |
| [aws_cloudwatch_event_target.s3_event_target](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_target) | resource |
| [aws_cloudwatch_event_target.ssiparam_event_target](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_target) | resource |
| [aws_cloudwatch_event_target.ssiparam_event_target_v2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_target) | resource |
| [aws_cloudwatch_metric_alarm.cloudfront](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_metric_alarm) | resource |
| [aws_cloudwatch_metric_alarm.s3](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_metric_alarm) | resource |
| [aws_iam_policy.bucket_replication_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_role.bucket_replication_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.eventbridge_iam_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy_attachment.bucket_replication_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_lambda_permission.cloudwatch_permission](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |
| [aws_lambda_permission.cloudwatch_permission_v2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |
| [aws_lambda_permission.s3_cloudwatch_permission](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |
| [aws_route53_record.aws_evernorthcloud_private_record](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.aws_evernorthcloud_public_record](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.aws_evernorthcloud_site_cert](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.custom_site_cert](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.custom_site_private](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.custom_site_public](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.site_cert](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.site_private](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.site_public](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.wildcard_site_cert](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.wildcard_site_private](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.wildcard_site_public](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_s3_bucket.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_bucket_acl.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_acl) | resource |
| [aws_s3_bucket_acl.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_acl) | resource |
| [aws_s3_bucket_cors_configuration.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_cors_configuration) | resource |
| [aws_s3_bucket_cors_configuration.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_cors_configuration) | resource |
| [aws_s3_bucket_metric.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_metric) | resource |
| [aws_s3_bucket_metric.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_metric) | resource |
| [aws_s3_bucket_ownership_controls.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_ownership_controls) | resource |
| [aws_s3_bucket_ownership_controls.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_ownership_controls) | resource |
| [aws_s3_bucket_policy.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_policy) | resource |
| [aws_s3_bucket_policy.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_policy) | resource |
| [aws_s3_bucket_public_access_block.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_public_access_block) | resource |
| [aws_s3_bucket_public_access_block.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_public_access_block) | resource |
| [aws_s3_bucket_replication_configuration.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_replication_configuration) | resource |
| [aws_s3_bucket_server_side_encryption_configuration.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_server_side_encryption_configuration) | resource |
| [aws_s3_bucket_server_side_encryption_configuration.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_server_side_encryption_configuration) | resource |
| [aws_s3_bucket_versioning.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_versioning) | resource |
| [aws_s3_bucket_versioning.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_versioning) | resource |
| [aws_ssm_parameter.config_ssm_params](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_parameter) | resource |
| [aws_ssm_parameter.config_ssm_params_v2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_parameter) | resource |
| [random_string.unique_id](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/string) | resource |
| [aws_caller_identity.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_caller_identity.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_cloudfront_cache_policy.reused_cache_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/cloudfront_cache_policy) | data source |
| [aws_iam_account_alias.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_account_alias) | data source |
| [aws_iam_policy_document.bucket_replication_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.eventbridge_assume_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.failover_bucket_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.fetch_params_lambda_policy_doc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.primary_bucket_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.req_lambda_policy_doc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_role.deployer_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_role) | data source |
| [aws_iam_roles.accountadmin_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_roles) | data source |
| [aws_region.failover](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [aws_region.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [aws_route53_zone.aws_evernorthcloud_private_zone](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |
| [aws_route53_zone.aws_evernorthcloud_public_zone](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |
| [aws_route53_zone.custom_private_zone](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |
| [aws_route53_zone.custom_public_zone](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |
| [aws_route53_zone.private_hosted_zone](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |
| [aws_route53_zone.public_hosted_zone](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/route53_zone) | data source |
| [aws_ssm_parameter.private_hosted_zone](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |
| [aws_ssm_parameter.public_hosted_zone](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |
| [aws_ssm_parameter.ssi_params](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |
| [aws_ssm_parameter.ssi_params_v2](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_alarm_funnel_app_name"></a> [alarm\_funnel\_app\_name](#input\_alarm\_funnel\_app\_name) | Application name as configured in the alarm funnel project | `string` | n/a | yes |
| <a name="input_alarm_prefix"></a> [alarm\_prefix](#input\_alarm\_prefix) | Prefix used for all alarms created by this module | `string` | n/a | yes |
| <a name="input_alternate_domain_names"></a> [alternate\_domain\_names](#input\_alternate\_domain\_names) | A list of domain names that can be used with the CloudFront distribution. It can also include a wildcard reference like *.example.com | `list(string)` | `[]` | no |
| <a name="input_cache_control_mappings"></a> [cache\_control\_mappings](#input\_cache\_control\_mappings) | The value for the HTTP Cache-Control header for various types of resources of this website. | <pre>object({<br/>    default = string<br/>    css     = string<br/>    images  = string<br/>    fonts   = string<br/>  })</pre> | <pre>{<br/>  "css": "max-age=600, s-maxage=300",<br/>  "default": "max-age=600, s-maxage=300",<br/>  "fonts": "max-age=7200, s-maxage=3600",<br/>  "images": "max-age=7200, s-maxage=3600"<br/>}</pre> | no |
| <a name="input_cache_default_ttl"></a> [cache\_default\_ttl](#input\_cache\_default\_ttl) | The default ttl for the default cache behavior. | `number` | `86400` | no |
| <a name="input_cache_max_ttl"></a> [cache\_max\_ttl](#input\_cache\_max\_ttl) | The max ttl for the default cache behavior. | `number` | `31536000` | no |
| <a name="input_cache_min_ttl"></a> [cache\_min\_ttl](#input\_cache\_min\_ttl) | The minimum ttl for the default cache behavior. | `number` | `1` | no |
| <a name="input_cache_options_responses"></a> [cache\_options\_responses](#input\_cache\_options\_responses) | Whether HTTP method OPTIONS should be cached or not. | `bool` | `true` | no |
| <a name="input_cache_policy_name"></a> [cache\_policy\_name](#input\_cache\_policy\_name) | Name of the CloudFront cache policy to be re-used | `string` | `""` | no |
| <a name="input_central_logging_destination_param"></a> [central\_logging\_destination\_param](#input\_central\_logging\_destination\_param) | Parameter in SSM that holds the arn for the centralized logging destination | `string` | `"/Enterprise/OrgCentralLoggingDestinationArn"` | no |
| <a name="input_certificate_arn"></a> [certificate\_arn](#input\_certificate\_arn) | ARN for an ACM certificate to use when making TLS connections (HTTPS) or leave empty to generate new certificate signed by ACM. | `string` | `""` | no |
| <a name="input_cloudfront_access_logs_bucket_domain_name"></a> [cloudfront\_access\_logs\_bucket\_domain\_name](#input\_cloudfront\_access\_logs\_bucket\_domain\_name) | The domain name of the bucket used to store access logs. Access logs are not set up if this is left null (you should only do this when configuring real time logging elsewhere). | `string` | `""` | no |
| <a name="input_cloudfront_access_logs_bucket_prefix"></a> [cloudfront\_access\_logs\_bucket\_prefix](#input\_cloudfront\_access\_logs\_bucket\_prefix) | Prefix used for all log objects. Should not start with a forward slash. | `string` | `""` | no |
| <a name="input_cloudfront_access_logs_log_cookies"></a> [cloudfront\_access\_logs\_log\_cookies](#input\_cloudfront\_access\_logs\_log\_cookies) | Whether or not cookies are included in access logs. | `bool` | `false` | no |
| <a name="input_cloudfront_alarms"></a> [cloudfront\_alarms](#input\_cloudfront\_alarms) | Used to specify thresholds for alarms for the cloudfront distribution. Setting a threshold to null disables the alarm. | <pre>object({<br/>    error_rate_4xx_INFO = number<br/>    error_rate_5xx_INFO = number<br/>    error_rate_5xx_CRIT = number<br/>    lambda_errors_INFO  = number<br/>    lambda_errors_CRIT  = number<br/>    error_rate_404_INFO = number<br/>    error_rate_401_INFO = number<br/>    error_rate_401_CRIT = number<br/>    error_rate_403_INFO = number<br/>    error_rate_403_CRIT = number<br/>    error_rate_502_INFO = number<br/>    error_rate_502_CRIT = number<br/>    error_rate_503_INFO = number<br/>    error_rate_503_CRIT = number<br/>    error_rate_504_INFO = number<br/>    error_rate_504_CRIT = number<br/>  })</pre> | <pre>{<br/>  "error_rate_401_CRIT": 30,<br/>  "error_rate_401_INFO": 15,<br/>  "error_rate_403_CRIT": 30,<br/>  "error_rate_403_INFO": 15,<br/>  "error_rate_404_INFO": 15,<br/>  "error_rate_4xx_INFO": 15,<br/>  "error_rate_502_CRIT": 30,<br/>  "error_rate_502_INFO": 15,<br/>  "error_rate_503_CRIT": 30,<br/>  "error_rate_503_INFO": 15,<br/>  "error_rate_504_CRIT": 30,<br/>  "error_rate_504_INFO": 15,<br/>  "error_rate_5xx_CRIT": 30,<br/>  "error_rate_5xx_INFO": 15,<br/>  "lambda_errors_CRIT": 10,<br/>  "lambda_errors_INFO": 1<br/>}</pre> | no |
| <a name="input_cloudfront_price_class"></a> [cloudfront\_price\_class](#input\_cloudfront\_price\_class) | Price class for the cloudfront distribution. | `string` | `"PriceClass_100"` | no |
| <a name="input_content_security_policy_directives"></a> [content\_security\_policy\_directives](#input\_content\_security\_policy\_directives) | The value for the HTTP Content-Security-Policy header for all resources of this website. | `map(string)` | <pre>{<br/>  "default-src": "'self' *.cigna.com *.cignacloud.com *.evernorth.com *.express-scripts.com *.medco.com",<br/>  "font-src": "'self' data: *.cigna.com *.cignacloud.com *.evernorth.com *.express-scripts.com *.medco.com fonts.googleapis.com fonts.gstatic.com",<br/>  "form-action": "'self'",<br/>  "frame-ancestors": "'self' *.cigna.com *.cignacloud.com *.evernorth.com *.express-scripts.com *.medco.com",<br/>  "frame-src": "'self'",<br/>  "object-src": "'none'",<br/>  "report-uri": "/report-csp-violation",<br/>  "script-src": "'self' data: *.cigna.com *.cignacloud.com *.evernorth.com *.express-scripts.com *.medco.com *.launchdarkly.com *.newrelic.com"<br/>}</pre> | no |
| <a name="input_cookie_behavior_config"></a> [cookie\_behavior\_config](#input\_cookie\_behavior\_config) | Determines whether any cookies in viewer requests are included in the cache key and automatically included in requests that CloudFront sends to s3. | `string` | `"none"` | no |
| <a name="input_cookie_forwarding_mode"></a> [cookie\_forwarding\_mode](#input\_cookie\_forwarding\_mode) | Specifies which cookies to forward to the s3 buckets through the default cache behavior. Useful if caching depends on cookies (typically not for s3). | `string` | `"none"` | no |
| <a name="input_cors_allow_credentials"></a> [cors\_allow\_credentials](#input\_cors\_allow\_credentials) | Whether HTTP Access-Control-Allow-Credentials header should be added. | `string` | `"true"` | no |
| <a name="input_cors_allowed_headers"></a> [cors\_allowed\_headers](#input\_cors\_allowed\_headers) | Value of HTTP Access-Control-Allow-Headers. | `list(string)` | <pre>[<br/>  "Authentication",<br/>  "Accept",<br/>  "Accept-Language",<br/>  "Content-Language",<br/>  "Content-Type"<br/>]</pre> | no |
| <a name="input_cors_allowed_methods"></a> [cors\_allowed\_methods](#input\_cors\_allowed\_methods) | Value of HTTP Access-Control-Allow-Methods. | `list(string)` | <pre>[<br/>  "GET",<br/>  "HEAD"<br/>]</pre> | no |
| <a name="input_cors_allowed_origins"></a> [cors\_allowed\_origins](#input\_cors\_allowed\_origins) | Value of HTTP Access-Control-Allow-Origin. | `list(string)` | `[]` | no |
| <a name="input_cors_expose_headers"></a> [cors\_expose\_headers](#input\_cors\_expose\_headers) | Value of HTTP Access-Control-Expose-Headers. | `list(string)` | <pre>[<br/>  "Content-Length",<br/>  "Content-Type",<br/>  "Date",<br/>  "ETag"<br/>]</pre> | no |
| <a name="input_cors_max_age"></a> [cors\_max\_age](#input\_cors\_max\_age) | Value of HTTP Access-Control-Max-Age. | `number` | `600` | no |
| <a name="input_create_cloudfront_access_logs_bucket"></a> [create\_cloudfront\_access\_logs\_bucket](#input\_create\_cloudfront\_access\_logs\_bucket) | Whether an S3 bucket for CloudFront access logs should be created or not. | `bool` | `false` | no |
| <a name="input_create_private_dns_record"></a> [create\_private\_dns\_record](#input\_create\_private\_dns\_record) | Set to true to create a private dns record for the site. May not be needed for public sites. Note, if you are using the COE-provided private zone, you will need to create this to resolve from on premise. | `bool` | `true` | no |
| <a name="input_create_public_dns_record"></a> [create\_public\_dns\_record](#input\_create\_public\_dns\_record) | Set to true to create a public dns record for the site. May not be needed for internal sites. | `bool` | `false` | no |
| <a name="input_custom_error_responses"></a> [custom\_error\_responses](#input\_custom\_error\_responses) | Grants the ability to return specific objects on an error. The default will return index.html on a 404 which is a common pattern for routing in SPA's as the framework's router will handle the routing based on the path in the url. | <pre>list(object({<br/>    error_code    = number<br/>    response_code = number<br/>    object        = string<br/>    ttl           = number<br/>  }))</pre> | <pre>[<br/>  {<br/>    "error_code": 404,<br/>    "object": "/index.html",<br/>    "response_code": 404,<br/>    "ttl": 300<br/>  }<br/>]</pre> | no |
| <a name="input_custom_failover_origin"></a> [custom\_failover\_origin](#input\_custom\_failover\_origin) | Used for non-S3 origins for the CloudFront distribution. Only used if use\_custom\_origin is true | `string` | `""` | no |
| <a name="input_custom_hosted_zone_name"></a> [custom\_hosted\_zone\_name](#input\_custom\_hosted\_zone\_name) | Sub-domain name which will serve as the base for the hosted zone(s). | `string` | `""` | no |
| <a name="input_custom_primary_origin"></a> [custom\_primary\_origin](#input\_custom\_primary\_origin) | Used for non-S3 origins for the CloudFront distribution. Only used if use\_custom\_origin is true | `string` | `""` | no |
| <a name="input_default_root_object"></a> [default\_root\_object](#input\_default\_root\_object) | Object that is served when viewers access the root of the site | `string` | `"index.html"` | no |
| <a name="input_distribution_name"></a> [distribution\_name](#input\_distribution\_name) | Used for comments on the CloudFront distribution + origin access identity. | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | The logical environment being deployed into or leave blank to use AWS account environment. | `string` | `""` | no |
| <a name="input_evernorth_private_hosted_zone_param"></a> [evernorth\_private\_hosted\_zone\_param](#input\_evernorth\_private\_hosted\_zone\_param) | Parameter in ssm that holds the hosted zone id for the Evernorth private hosted zone. | `string` | `"/Enterprise/EvernorthcloudPrivateHostedZoneId"` | no |
| <a name="input_evernorth_public_hosted_zone_param"></a> [evernorth\_public\_hosted\_zone\_param](#input\_evernorth\_public\_hosted\_zone\_param) | Parameter in ssm that holds the hosted zone id for the Evernorth public hosted zone. | `string` | `"/Enterprise/EvernorthcloudPublicHostedZoneId"` | no |
| <a name="input_evernorthcloud_zone_domain"></a> [evernorthcloud\_zone\_domain](#input\_evernorthcloud\_zone\_domain) | The domain for the aws.evernorthcloud.com hosted zone | `string` | `""` | no |
| <a name="input_extra_behaviors"></a> [extra\_behaviors](#input\_extra\_behaviors) | Map of cloudfront behaviors | <pre>list(object({<br/>    path_pattern    = string<br/>    origin_name     = string<br/>    allowed_methods = string<br/>    lambdas = list(object({<br/>      event_type           = string<br/>      lambda_qualified_arn = string<br/>    }))<br/>    forwarded_values = list(object({<br/>      forwarded_headers_list            = list(string)<br/>      forwarded_query_string            = bool<br/>      forwarded_query_string_cache_keys = list(string)<br/>      cookie_forwarding_mode            = string<br/>      forwarded_cookie_list             = list(string)<br/>    }))<br/>  }))</pre> | `[]` | no |
| <a name="input_extra_origin_headers"></a> [extra\_origin\_headers](#input\_extra\_origin\_headers) | Maps custom origin name to a list of headers | <pre>map(list(object({<br/>    name  = string<br/>    value = string<br/>  })))</pre> | `{}` | no |
| <a name="input_extra_origins"></a> [extra\_origins](#input\_extra\_origins) | Adds custom origins | <pre>list(object({<br/>    name   = string<br/>    domain = string<br/>  }))</pre> | `[]` | no |
| <a name="input_failover_bucket_kms_key_id"></a> [failover\_bucket\_kms\_key\_id](#input\_failover\_bucket\_kms\_key\_id) | An existing KMS key id used to encrypt the bucket contents or null to generate new | `string` | `""` | no |
| <a name="input_failover_bucket_name"></a> [failover\_bucket\_name](#input\_failover\_bucket\_name) | Name of the failover s3 bucket | `string` | `""` | no |
| <a name="input_failover_region"></a> [failover\_region](#input\_failover\_region) | The region where the failover bucket will be created. | `string` | `"us-east-2"` | no |
| <a name="input_fetch_ssm_param_template_file"></a> [fetch\_ssm\_param\_template\_file](#input\_fetch\_ssm\_param\_template\_file) | Override default Lambda code that fetches environment configuration from the SSM param store. | `string` | `""` | no |
| <a name="input_force_destroy_bucket"></a> [force\_destroy\_bucket](#input\_force\_destroy\_bucket) | Boolean for forcibly destroying the s3 bucket | `bool` | `false` | no |
| <a name="input_force_destroy_failover_bucket"></a> [force\_destroy\_failover\_bucket](#input\_force\_destroy\_failover\_bucket) | Boolean for forcibly destroying the s3 failover bucket | `bool` | `false` | no |
| <a name="input_forward_lambda_logs"></a> [forward\_lambda\_logs](#input\_forward\_lambda\_logs) | Whether logs from the edge lambdas should be pushed to centralized logging infrastructure. | `bool` | `false` | no |
| <a name="input_forward_query_string"></a> [forward\_query\_string](#input\_forward\_query\_string) | Whether or not to forward query strings to the s3 buckets through the default cache behavior. Useful if caching depends on the query strings (typically not for s3). | `bool` | `false` | no |
| <a name="input_forwarded_cookies"></a> [forwarded\_cookies](#input\_forwarded\_cookies) | A list of specific cookies to forward to the s3 buckets through the default cache behavior. Useful if caching depends on cookies (typically not for s3). | `list(string)` | `[]` | no |
| <a name="input_forwarded_headers"></a> [forwarded\_headers](#input\_forwarded\_headers) | A list of specific headers to forward to the s3 buckets through the default cache behavior. | `list(string)` | <pre>[<br/>  "Origin",<br/>  "Access-Control-Request-Headers",<br/>  "Access-Control-Request-Method",<br/>  "Authorization"<br/>]</pre> | no |
| <a name="input_forwarded_query_strings"></a> [forwarded\_query\_strings](#input\_forwarded\_query\_strings) | A list of specific query strings to forward to the s3 buckets through the default cache behavior. | `list(string)` | `[]` | no |
| <a name="input_global_lambda_alarms"></a> [global\_lambda\_alarms](#input\_global\_lambda\_alarms) | Used to specify thresholds for alarms for the unreserved lambda concurrency (used by lambda@edge). Setting a threshold to null disables the alarm. | <pre>object({<br/>    concurrency_INFO = number<br/>    concurrency_WARN = number<br/>  })</pre> | <pre>{<br/>  "concurrency_INFO": 100,<br/>  "concurrency_WARN": 500<br/>}</pre> | no |
| <a name="input_header_behavior_config"></a> [header\_behavior\_config](#input\_header\_behavior\_config) | Determines whether any HTTP headers are included in the cache key and automatically included in requests that CloudFront sends to s3 | `string` | `"whitelist"` | no |
| <a name="input_kms_key_accounts"></a> [kms\_key\_accounts](#input\_kms\_key\_accounts) | List of accounts with KMS key access privileges. Defaults to the containing account. | `list(string)` | `[]` | no |
| <a name="input_kms_key_administrators"></a> [kms\_key\_administrators](#input\_kms\_key\_administrators) | List of roles with KMS key administration privileges. Defaults to [ACCOUNTADMIN, CLOUDADMIN, DEPLOYER]. | `list(string)` | `[]` | no |
| <a name="input_kms_key_users"></a> [kms\_key\_users](#input\_kms\_key\_users) | List of roles with KMS key usage privileges. Defaults to resources in the containing account. | `list(string)` | `[]` | no |
| <a name="input_name_prefix"></a> [name\_prefix](#input\_name\_prefix) | A setting to use for naming resources when multiple distributions are deployed in the same AWS account | `string` | `""` | no |
| <a name="input_oac_enabled"></a> [oac\_enabled](#input\_oac\_enabled) | If true, the Origin Access Control will gets created | `bool` | `false` | no |
| <a name="input_optional_data_tags"></a> [optional\_data\_tags](#input\_optional\_data\_tags) | Optional Cigna data at rest tags (reference https://confluence.sys.cigna.com/display/CLOUD/Cloud+Tagging+Requirements+v2.0). | `map(string)` | `{}` | no |
| <a name="input_optional_tags"></a> [optional\_tags](#input\_optional\_tags) | Optional Cigna standard tags (reference https://confluence.sys.cigna.com/display/CLOUD/Cloud+Tagging+Requirements+v2.0). | `map(string)` | `{}` | no |
| <a name="input_origin_req_template_file"></a> [origin\_req\_template\_file](#input\_origin\_req\_template\_file) | Override default origin request lambda code template which signs S3 requests by default | `string` | `""` | no |
| <a name="input_origin_resp_template_file"></a> [origin\_resp\_template\_file](#input\_origin\_resp\_template\_file) | Override default origin response lambda code template which adds security and cache headers by default | `string` | `""` | no |
| <a name="input_primary_bucket_alarms"></a> [primary\_bucket\_alarms](#input\_primary\_bucket\_alarms) | Used to specify thresholds for alarms for the primary s3 bucket. Setting a threshold to null disables the alarm. | <pre>object({<br/>    error_rate_4xx_INFO = number<br/>    error_rate_5xx_INFO = number<br/>  })</pre> | <pre>{<br/>  "error_rate_4xx_INFO": 10,<br/>  "error_rate_5xx_INFO": 1<br/>}</pre> | no |
| <a name="input_primary_bucket_kms_key_id"></a> [primary\_bucket\_kms\_key\_id](#input\_primary\_bucket\_kms\_key\_id) | An existing KMS key id used to encrypt the bucket contents or null to generate new | `string` | `""` | no |
| <a name="input_primary_bucket_name"></a> [primary\_bucket\_name](#input\_primary\_bucket\_name) | Name of the primary s3 bucket | `string` | `""` | no |
| <a name="input_private_hosted_zone_enabled"></a> [private\_hosted\_zone\_enabled](#input\_private\_hosted\_zone\_enabled) | Setting to false does not create the private hosted zone | `bool` | `true` | no |
| <a name="input_private_hosted_zone_param"></a> [private\_hosted\_zone\_param](#input\_private\_hosted\_zone\_param) | Parameter in ssm that holds the hosted zone id for the private hosted zone. | `string` | `"/Enterprise/PrivateHostedZoneId"` | no |
| <a name="input_process_custom_cert"></a> [process\_custom\_cert](#input\_process\_custom\_cert) | Set to true when using custom hosted zones and to trigger the ACM cert creation and cert validation. Ideally should be done after any DNS changes to point to the Route 53 NS and SOA records. | `bool` | `false` | no |
| <a name="input_prod_blue_deployment"></a> [prod\_blue\_deployment](#input\_prod\_blue\_deployment) | Whether this is a prod blue deployment. Used to publish prod blue alarms to the correct SNS topic | `bool` | `false` | no |
| <a name="input_public_hosted_zone_param"></a> [public\_hosted\_zone\_param](#input\_public\_hosted\_zone\_param) | Parameter in ssm that holds the hosted zone id for the public hosted zone. | `string` | `"/Enterprise/PublicHostedZoneId"` | no |
| <a name="input_query_string_behavior_config"></a> [query\_string\_behavior\_config](#input\_query\_string\_behavior\_config) | Determines whether any URL query strings in viewer requests are included in the cache key and automatically included in requests that CloudFront sends to s3 | `string` | `"none"` | no |
| <a name="input_replicate_to_failover_bucket"></a> [replicate\_to\_failover\_bucket](#input\_replicate\_to\_failover\_bucket) | Whether S3 cross-region replication to the failover bucket should be enabled | `bool` | `false` | no |
| <a name="input_required_data_tags"></a> [required\_data\_tags](#input\_required\_data\_tags) | Required Cigna data at rest tags (reference https://confluence.sys.cigna.com/display/CLOUD/Cloud+Tagging+Requirements+v2.0). | <pre>object({<br/>    BusinessEntity         = string<br/>    ComplianceDataCategory = string<br/>    DataClassification     = string<br/>    DataSubjectArea        = string<br/>    LineOfBusiness         = string<br/>  })</pre> | n/a | yes |
| <a name="input_required_tags"></a> [required\_tags](#input\_required\_tags) | Required common resource tags as defined by the CCOE Cloud Tagging Requirements | <pre>object({<br/>    AssetOwner       = string<br/>    CostCenter       = string<br/>    SecurityReviewID = string<br/>    ServiceNowAS     = string<br/>    ServiceNowBA     = string<br/>  })</pre> | n/a | yes |
| <a name="input_reuse_cache_policy"></a> [reuse\_cache\_policy](#input\_reuse\_cache\_policy) | If true, reuses the existing CloudFront cache policy by providing name of policy in the tfvars file | `bool` | `false` | no |
| <a name="input_ssi_config_variables"></a> [ssi\_config\_variables](#input\_ssi\_config\_variables) | Server side include configuration values that will be sent back in the response for index.html | `map(map(string))` | `{}` | no |
| <a name="input_ssi_config_variables_v2"></a> [ssi\_config\_variables\_v2](#input\_ssi\_config\_variables\_v2) | The v2 version for supporting server side include configuration values that will be sent back in the response for index.html | `map(map(string))` | `{}` | no |
| <a name="input_ssi_configuration"></a> [ssi\_configuration](#input\_ssi\_configuration) | The v2 version for supporting server side include configuration values that will be sent back in the response for index.html | <pre>list(object({<br/>    params      = map(map(string))<br/>    object_path = string<br/>    app_name    = string<br/>  }))</pre> | `[]` | no |
| <a name="input_ssi_object_path"></a> [ssi\_object\_path](#input\_ssi\_object\_path) | Path to the index.html that needs to contain the SSI replacement | `string` | `"index.html"` | no |
| <a name="input_ssi_object_path_v2"></a> [ssi\_object\_path\_v2](#input\_ssi\_object\_path\_v2) | Path to the index.html for the app that needs to contain the SSI replacement | `map(map(string))` | `{}` | no |
| <a name="input_strict_transport_security_max_age"></a> [strict\_transport\_security\_max\_age](#input\_strict\_transport\_security\_max\_age) | The max-age value for Strict-Transport-Security header | `number` | `604800` | no |
| <a name="input_subdomain"></a> [subdomain](#input\_subdomain) | The subdomain of the site. Primary domain will be taken from the domain name in the public hosted zone. To use the root domain, set this to be empty. | `string` | n/a | yes |
| <a name="input_use_aws_evernorthcloud_hosted_zone"></a> [use\_aws\_evernorthcloud\_hosted\_zone](#input\_use\_aws\_evernorthcloud\_hosted\_zone) | Set to true to allow creation of the aws.evernorthcloud.com hosted zone. | `bool` | `false` | no |
| <a name="input_use_custom_hosted_zone"></a> [use\_custom\_hosted\_zone](#input\_use\_custom\_hosted\_zone) | Set to true to use hosted zone(s) with different SOA record than the default. | `bool` | `false` | no |
| <a name="input_use_custom_origin"></a> [use\_custom\_origin](#input\_use\_custom\_origin) | Set to false to true to use a non-S3 origin | `bool` | `false` | no |
| <a name="input_use_evernorth_hosted_zone"></a> [use\_evernorth\_hosted\_zone](#input\_use\_evernorth\_hosted\_zone) | Set to true to use the hosted zone for evernorthcloud.com | `bool` | `false` | no |
| <a name="input_use_forwarded_values"></a> [use\_forwarded\_values](#input\_use\_forwarded\_values) | Whether or not to setup the default cache behavior with forwarded values. The default value of false enables creation of the cache policy required for compression. | `bool` | `false` | no |
| <a name="input_use_ssi_v2"></a> [use\_ssi\_v2](#input\_use\_ssi\_v2) | Set to true for using the v2 version of support for server side includes | `bool` | `false` | no |
| <a name="input_use_ssi_variables"></a> [use\_ssi\_variables](#input\_use\_ssi\_variables) | Whether environment level variables are used to implement SSI | `bool` | `false` | no |
| <a name="input_use_wildcard_certificate"></a> [use\_wildcard\_certificate](#input\_use\_wildcard\_certificate) | Setting that will generate a wildcard certificate to enable alternate domain names | `bool` | `false` | no |
| <a name="input_validate_custom_acm_cert"></a> [validate\_custom\_acm\_cert](#input\_validate\_custom\_acm\_cert) | Whether or not the custom cert is validated after creation.  Set to false, to skip DNS validation so terraform build will finish. | `bool` | `true` | no |
| <a name="input_validation_timeout"></a> [validation\_timeout](#input\_validation\_timeout) | ARN for an ACM certificate to use when making TLS connections (HTTPS) or leave empty to generate new certificate signed by ACM. | `string` | `"5m"` | no |
| <a name="input_waf_channel_tag"></a> [waf\_channel\_tag](#input\_waf\_channel\_tag) | The tag used for automatic WAF assignment.  Takes precedence over any waf\_type and waf\_id settings. | `string` | `"glo_internal_v2"` | no |
| <a name="input_waf_id"></a> [waf\_id](#input\_waf\_id) | The custom waf id to attach to the distribution. Only needed when waf\_type is set to custom. | `string` | `""` | no |
| <a name="input_waf_type"></a> [waf\_type](#input\_waf\_type) | The WAF to attach to the distribution | `string` | `"private"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_distribution_id"></a> [distribution\_id](#output\_distribution\_id) | Id of the CloudFront distribution |
<!-- END_TF_DOCS -->