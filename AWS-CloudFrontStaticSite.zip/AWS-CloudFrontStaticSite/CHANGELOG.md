# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v1.5.5] - 2025-01-15
### Added
* Added origin access control resource (OAC). Its a flag based, default will be false, if "oac_enabled" is set to true, then OAC will be created.
* Modified s3-bucket policy to get access for created OAC
* Modified KMS policy to get the access for OAC.

## [v1.5.4] - 2024-10-29
### Fixed
* When there is no infrastructure change, terraform apply now works properly by not modifying lambda and default cache behavior
### Added
* Strict Transport Security header is now configurable
* Introduced new variable 'strict_transport_security_max_age' to be configurable in tfvars

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.5.3...v1.5.4


## [v1.5.3] - 2024-07-24
### Fixed
* ACCOUNTADMIN role no longer exists in higher environments (test and prod). This release fixes issues that teams had in terraform plan stage for malformed policy for kms_key_administrators

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.5.2...v1.5.3


## [v1.5.2] - 2024-06-06
### Added
* Release enables reusage of existing CloudFront cache policy. This is done to enable teams that are deploying more than 10 static content applications in the account. There is a default limit of 20 cache policies and once hit teams get an error in the pipeline for quota limit.
New flag introduced: reuse_cache_policy. By default set to false. Set to true in .tfvars to enable functionality
New variable cache_policy_name. Provide the name of existing cache policy name in .tfvars

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.5.1...v1.5.2

## [v1.5.1] - 2024-05-22
### Fixed
* Fix in release 1.5.0 with a variable reference when using a wildcard certificate

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.5.0...v1.5.1

## [v1.5.0] - 2024-05-21
### Added
* Revert "cl: removed /* from s3 bucket policies" by @Christopher-Sardegna-H14384
* Use latest AWS Provider by @Christopher-Sardegna-H14384
* Updated terraform version by @Gulzina-Eshbaeva-C7G3N2
* Allow bucket ACL by @Nicolas-Trettel-H64694
* Fix typo when referencing failover bucket by @Nicolas-Trettel-H64694
* add codeowners file by @Kevin-Brockhoff-EN5575
* Support NodeJS 20 by @Leela-Nimmagadda-C7Z4WT
* NodeJS20 support by @Leela-Nimmagadda-C7Z4WT
* updated runtime list by @Beksultan-Midinov-C7Z9ZG
* Apply forwarded cookies list to default cache policy by @Justin-Gable-C7D9NX
* Hs aws 5.x by @Beksultan-Midinov-C7Z9ZG
* Update tests to work with GitHub Actions by @Alex-Tran-C7Q4XP
* Raised edge lambda deletion timeout by @Alex-Tran-C7Q4XP
* enable delete marker replication and make bucket replication dependent on bucket versioning by @Luc-Nuytten-H17931
* Spike/ispca 1060 by @Vinay-Menon-EM8675
* Don't create hosted zones by @Nicolas-Trettel-H64694

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.4.0...v1.5.0

## [v1.4.0] - 2024-02-26
### Added
* Lambda@Edge node 20 support

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.3.1...v1.4.0

## [v1.3.1] - 2024-02-27
### Added
* Lambda@Edge runtime list updated
* Apply forwarded cookies list to default cache policy

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.3.0...v1.3.1

## [v1.3.0] - 2024-01-04
### Added
* Automation of SSI Replacement on S3 upload. When code is uploaded to s3 and teams are leveraging V2 of the SSI feature, an event bridge rule kicks off the SSI replacement lambda. This removes the need for a manual step to edit and save a parameter in order for the replacement to happen.

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.2.1...v1.3.0

## [v1.2.1] - 2023-12-29
### Fixed
* Based on the branch hs-aws-5.x. This is a small patch fix for the log bucket versioning configuration. Setting Version configuration to 'SUSPENDED' from 'DISABLED'.

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.2.0...v1.2.1

## [v1.2.0] - 2023-12-28
### Added
* AWS Provider v5 support

### Important notes
* If you are upgrading from v0.15.x - v0.19.x there are changes required:
 * Update tfVersion in Jenkinsfile to "1.1.0"
 * Update provider version constraints to ">= 4.41, < 6.0.0" in your main.tf
 * Update source = "git::https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite.git?ref=v1.2.0" in main.tf

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.0.6...v1.2.0

## [v1.0.6] - 2023-11-08
### Added
* The extra_behaviors object now requires a new list object `forwarded_values = []`. When empty, the default cache policy will be associated to the behavior

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.0.4...v1.0.6

## [v1.0.4] - 2023-10-24
### Fixed
* Fix for input validation error message
### Added
* New optional variable `name_prefix` used to further qualify resource names when multiple apps are deployed in the same AWS account using this pattern. Currently this is being used only on an IAM role tied to eventbridge

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v1.0.3...v1.0.4

## [v1.0.3] - 2023-10-10
### Added
* Breaking changes associated to s3 buckets with v4 or AWS provider were addressed
* Lambda@Edge runtime default was updated to nodejs18.x
### Important notes
* In your Jenkinsfile update tfVersion to "1.1.0"
* Update AWS provider range to ">= 4.41.0, < 5.0.0" in your main.tf
* Update source = "git::https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite.git?ref=v1.0.3" in main.tf

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.19.10...v1.0.3

## [v0.19.10] - 2023-10-06
### Added 
*  The `extra_behaviors` object now requires a new list object `forwarded_values = []`. When empty, the default cache policy will be associated to the behavior

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.19.9...v0.19.10

## [v0.19.9] - 2023-08-16
### Added
* Support to specify query string parameter list when `query_string_behavior_config` is set to `whitelist` or `allExcept`

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.19.7...v0.19.9

## [v0.19.7] - 2023-07-07
### Added
* Server side includes (ssi) v2. Implementation guide: https://confluence.sys.cigna.com/display/CCoP/Updates+to+handle+CUPS+in+AWS+hosted+static+content#UpdatestohandleCUPSinAWShostedstaticcontent-V2ChangesV2

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.19.6...v0.19.7

## [v0.19.6] - 2023-05-26
### Added
* Ability to set the allowed HTTP Methods on a Cloudfront behavior
* Added property `allowed_methods` to `extra_behaviors`

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.19.5...v0.19.6

## [v0.19.5] - 2023-05-08 
### Added
* Ability to send a Header to an origin. 
* Added `extra_origin_headers` variable
* Added `add_custom_private_zone` variable instead of hardcoding the value to true. 
### Note
The Header is a name value object. It gets set only if you have `extra_origins` defined

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.19.4...v0.19.5

## [v0.19.4] - 2023-04-17
### Added
* Support for server side includes (SSI). `use_ssi_variables` = # when set to true it will use the `ssi_config_variables` variables configuration values

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.19.3...v0.19.4

## [v0.19.3] - 2023-04-10
### Added
* Creation of custom hosted zones and manage its Terraform state independently of the core infrastructure resources. Documentation on this feature can be found at https://confluence.sys.cigna.com/display/CCoP/Hosted+zone+Terraform+state+management
### Notes
* This release targets the v3.X version of the AWS provider

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.19.0...v0.19.3

## [v0.19.0] - 2022-10-04
### Added
* TLS cloudfront version changed to TLSv1.2_2021

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.15.5...v0.19.0

## [v0.15.5] - 2022-07-14
### Added 
* Enabling deployments in the prod blue region to use the prod alarm funnel setup.
New boolean variable `prod_blue_deployment` (defaults to false) allows the team to use the prod SNS topic for the alarm funnel.
Set it to true in the appropriate environment.tfvars file.

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.15.4...v0.15.5

## [v0.15.4] - 2022-06-06
### Added
* Validation to bucket names, lambda role names, and the constructed site url to ensure they are not too long.

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.15.3...v0.15.4

## [v0.15.3] - 2022-05-06
### Added
* Updates the centralized logging module to use the newer SSM parameter name for the centralized logging destination ARN. A new variable `central_logging_destination_param` with the default value of "/Enterprise/OrgCentralLoggingDestinationArn" enables this. A corresponding RaaS change was needed to allow the ssm:GetParameter on this new ARN.

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.15.2...v0.15.3

## [v0.15.2] - 2022-04-21
### Added
* Input validation for subdomain is added to make sure that it is all lowercase. This resolves an issue between CloudFront (which automatically lower-cases the domain) and ACM which doesn't make any adjustment.

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.15.1...v0.15.2

## [v0.15.1] - 2022-03-24
### Changed
* Update to v2 tagging requirements introduced (https://confluence.sys.cigna.com/display/CLOUD/Cloud+Tagging+Requirements+v2.0)
### Added
* New input variables: 
`required_tags` replaces `required_common_tags`
`optional_tags` replaces `extra_tags`
* Variable definition updated: `required_data_tags` object variable has two new attributes.
BusinessEntity = string
LineOfBusiness = string

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.15.0...v0.15.1


## [v0.15.0] - 2022-03-11
### Added
* Support adding behaviors to Cloudfront
### Enhancements
* Added dynamic resource for `ordered_cache_behavior`. This allows users to add behaviors to cloudfront.
* Added dynamic resource for `extra_origins`. This allows users to add (non s3) origins to cloudfront.

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.14.1...v0.15.0

## [v0.14.1] - 2021-10-26
### Added
* Ability to do a two step process when setting up a custom hosted zone and the DNS validation for the associated ACM CNAME records.

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.14.0...v0.14.1

## [v0.14.0] - 2021-10-19
### Added
* Support for alternate domain names. 
* To enable the use of this feature set the following variables in the child module
use_custom_hosted_zone = true
#Set to the domain name you want
custom_hosted_zone_name = "mydomain.com"
#List of alternate domain names that needs to be added
alternate_domain_names = ["adopt.mydomain.com", "user.mydomain.com", "mydomain.com"]

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.13.1...v0.14.0

## [v0.13.1] - 2021-09-23
### Fixed
* Bug fix for error when toggling the `create_cloudfront_access_logs_bucket` boolean flag. Added conditional expression to the policy related Terraform resource blocks to allow for toggling of the `create_cloudfront_access_logs_bucket` boolean flag.

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.13.0...v0.13.1

## [v0.13.0] - 2021-08-13
### Added
* Support for using the Route 53 hosted zones(public/private) for evernorthcloud.com
* CloudFront distributions can now be associated to the evernorthcloud.com domain
* New boolean variable `use_evernorth_hosted_zone` will be used to determine if a workload is using the cignacloud.com or evernorthcloud.com hosted zones.

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.12.0...v0.13.0

## [v0.12.0] - 2021-08-10
### Added
* Support for CloudFront to compress files and serve the compressed files when requested
* Hardened (policies) the workload specific S3 bucket that can be used for CloudFront access logs
* New boolean variable `use_forwarded_values` introduced in the root module. Defaults as false. It drives the creation of the cache policy required for compression.
* If `use_forwarded_values` is set to true the module will ignore/not create the cache policy.
* The S3 bucket for CloudFront access logs that can be provisioned by setting `create_cloudfront_access_logs_bucket` = true has the appropriate bucket policy and public access block attached to it.

**Full Changelog**: https://github.sys.cigna.com/cigna/AWS-CloudFrontStaticSite/compare/v0.11.0...v0.12.0

## [v0.11.0] - 2021-07-27
- Initial Release
### Added
* Realtime metrics enabled in CloudFront to alarm on specific http error codes