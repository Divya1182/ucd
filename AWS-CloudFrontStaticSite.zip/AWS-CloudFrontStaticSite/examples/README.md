# Module Usage Examples

## Minimal Required Variables

The example in `min-resources` only sets variable values where no defaults
are provided. This results in the creation of a PKI certificate signed by
the AWS Certificate Manager for TLS usage. It also results in the creation
of 2 KMS custom-managed keys for S3 bucket encryption in the 2 AWS regions
used as sources for the CloudFront distribution.

## Setting of All Variables

The example in `all-resources` sets all variable values. The ARNs for an
existing PKI certificate and KMS keys are passed in so no new ones are
created. It also gives an example of replacing the code template for the
response headers Lambda@Edge with a custom one.

## Setting Create Access Logs Bucket

The example in `with-logbucket` sets variable values where no defaults
are provided plus the create access logs bucket flag and associated values.

## Module Import 

The example in `main` represents the import of this Golden Terraform module.
The files in this folder is all that is needed to start using the module.
See [examples/main/static.auto.tfvars](examples/main/static.auto.tfvars) for inputs to the module. Rename it as needed and update it with required values. 