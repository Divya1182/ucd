'use strict';
exports.handler = (event, context, callback) => {

    const response = event.Records[0].cf.response;
    const headers = response.headers;
    const contentTypeHeader = headers['content-type'];
    const contentType = contentTypeHeader !== undefined && contentTypeHeader.length > 0 ?
        contentTypeHeader[0].value : 'text/plain';

    // Set new headers
    headers['strict-transport-security'] = [{
        key: 'Strict-Transport-Security',
        value: 'max-age=604800; includeSubdomains; preload'
    }];
    headers['content-security-policy'] = [{
        key: 'Content-Security-Policy',
        value: "default-src 'self'"
    }];
    headers['x-content-type-options'] = [{key: 'X-Content-Type-Options', value: 'nosniff'}];
    headers['x-frame-options'] = [{key: 'X-Frame-Options', value: 'DENY'}];
    headers['x-xss-protection'] = [{key: 'X-XSS-Protection', value: '1; mode=block'}];
    headers['referrer-policy'] = [{key: 'Referrer-Policy', value: 'same-origin'}];
    // Cache control added here instead of per S3 object
    headers['cache-control'] = [{key: 'Cache-Control', value: "max-age=900"}];

    // Return modified response
    callback(null, response);
};
