package com.cigna.s3.intentartifact.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Response;
import software.amazon.awssdk.services.s3.model.S3Exception;
import software.amazon.awssdk.services.s3.model.S3Object;
import software.amazon.awssdk.services.s3.paginators.ListObjectsV2Iterable;

import java.util.ArrayList;
import java.util.List;

@Service
public class S3Service {
    private final Logger logger = LoggerFactory.getLogger(S3Service.class);

    @Value("${aws.s3.bucket.name}")
    private String bucketName;

    public S3Service(){}


    public List<S3Object> listObjects() throws Exception {
        List<S3Object> responseList = new ArrayList<>();
        logger.info("S3 BUCKET NAME: " + bucketName);

        logger.info("S3Service Invoked and will be using S3Client to fetch Objects from Bucket - " + bucketName);
        ListObjectsV2Request listObjectsV2Request = ListObjectsV2Request.builder()
                .bucket(bucketName)
                .build();
        try {
            S3Client s3Client = S3Client.builder()
                    .region(Region.of(System.getenv("AWS_REGION")))
                    .credentialsProvider(DefaultCredentialsProvider.create())
                    .build();
            logger.info("S3 Client created and will be used for fetching the object list");
            ListObjectsV2Iterable listObjectsV2Iterable = s3Client.listObjectsV2Paginator(listObjectsV2Request);
            for (ListObjectsV2Response page : listObjectsV2Iterable) {
                responseList.addAll(page.contents());
            }

            s3Client.close();
        } catch (S3Exception e) {
            e.printStackTrace();
            logger.error("Error occurred while invoking S3 Client 1: ", e);
        }
        return responseList;
    }
}

