package com.cigna.s3.intentartifact.controller;

import com.cigna.s3.intentartifact.services.DynamoDbService;
import com.cigna.s3.intentartifact.services.S3Service;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import software.amazon.awssdk.services.s3.model.S3Object;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(value = "/evernorth/v2/intents/testeks")
public class S3Controller {
    private final Logger logger = LoggerFactory.getLogger(S3Controller.class);

    private S3Service s3Service;

    @Autowired
    public S3Controller(S3Service s3Service) {
        this.s3Service = s3Service;
    }

    @GetMapping(value = "/list-objects", produces = "application/json")
    public ResponseEntity listObjects() {
        try {
            List<S3Object> objectList = s3Service.listObjects();
            int objectCount = objectList.size();

            ObjectMapper mapper = new ObjectMapper();
            StringBuilder builder = new StringBuilder();
            builder.append("{\"count\":" + objectCount + ",");
            builder.append("\"S3Objects\":[");
            int counter = 0;
            for (S3Object object : objectList) {
                counter++;
                builder.append("\"" + object.key() + "\"");
                if (counter != objectCount) {
                    builder.append(",");
                }
            }
            builder.append("]}");
            return ResponseEntity.status(HttpStatus.OK).body(builder.toString());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    @GetMapping(path = "/hello")
    public ResponseEntity<String> sayHello(HttpServletRequest request) {
        System.out.println("Hello from EKS cluster !!!!!!!!!!!!!!!!!!!!");

        String sb = "{" + "\"isBase64Encoded\": \"false\"" +
                "\"statusCode\": \"200\"" +
                "\"body\": {\"Hello from EKS !\"}" +
                "}";

        return ResponseEntity.status(HttpStatus.ACCEPTED).body(sb);
    }
}