package com.cigna.s3.intentartifact.config;

import com.esrx.common.security.jwt.authentication.spring.JwtAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.stereotype.Component;

import com.esrx.inf.spring.boot.autoconfigure.security.HttpSecurityConfigurer;

@Component
public class WebSecurityConfiguration implements HttpSecurityConfigurer {

	@Override
	public void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
				.antMatchers("/api-docs", "/swagger-resources/**", "/swagger-ui.html", "/webjars/**", "/csrf", "/").permitAll()
				.antMatchers("/evernorth/v*/**").hasAuthority(JwtAuthenticationProvider.JWT_AUTHENTICATED_AUTHORITY_NAME);

	}
}