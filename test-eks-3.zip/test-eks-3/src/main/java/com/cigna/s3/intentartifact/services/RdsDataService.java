package com.cigna.s3.intentartifact.services;

import com.cigna.s3.intentartifact.model.PharmacyBenefit;
import com.cigna.s3.intentartifact.repository.PharmacyBenefitRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RdsDataService {


    @Autowired
    private PharmacyBenefitRepository pharmacyBenefitRepository;
    private final Logger logger = LoggerFactory.getLogger(RdsDataService.class);

    public List<PharmacyBenefit> executeQuery() {
        return pharmacyBenefitRepository.findAll();
    }
}
