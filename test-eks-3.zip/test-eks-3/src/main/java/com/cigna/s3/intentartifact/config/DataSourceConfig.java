package com.cigna.s3.intentartifact.config;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaxxer.hikari.HikariConfig;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.zaxxer.hikari.HikariDataSource;
import software.amazon.awssdk.auth.credentials.WebIdentityTokenFileCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;

@Configuration
public class DataSourceConfig {

    private static final Logger log = LoggerFactory.getLogger(DataSourceConfig.class);

    @Value("${spring.datasource.url}")
    private String jdbcUrl;

    @Value("${spring.datasource.username}")
    private String dbUsername;

    @Value("${spring.datasource.driver-class-name}")
    private String driverClassName;

    @Value("${aws.rds.secret-arn}")
    private String secretArn;

    @Value("${aws.rds.region}")
    private String regionName;

    @Bean
    public HikariDataSource dataSource(){
        log.info("Initializing HikariDataSource...");

        String password = fetchPasswordFromSecretManager(secretArn);

        log.debug("JDBC URL:{}",jdbcUrl);
        log.debug("DB Username:{}",dbUsername);
        log.debug("Driver ClassL:{}",driverClassName);

        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl(jdbcUrl);
        hikariConfig.setPassword(password);
        hikariConfig.setDriverClassName(driverClassName);

        log.info("HikariDataSource created succesfully");

        return new HikariDataSource(hikariConfig);

    }

    private String fetchPasswordFromSecretManager(String secretArn) {
        SecretsManagerClient client = SecretsManagerClient.builder().region(Region.of(regionName))
                .credentialsProvider(WebIdentityTokenFileCredentialsProvider.create()).build();

        GetSecretValueRequest request = GetSecretValueRequest.builder()
                .secretId(secretArn)
                .build();
        String secretString = client.getSecretValue(request).secretString();

        try{
            JsonNode jsonNode = new ObjectMapper().readTree(secretString);
            return jsonNode.get("password").asText();
        }catch(Exception e){
            throw new RuntimeException("Failed to parse secret JSON",e);
        }

    }


}
