#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Please pass the name of your plan file in json format"
    exit 1
fi

PAYLOAD=$(cat $1)

# Root Modules
echo $PAYLOAD | jq -c '[.planned_values.root_module.resources[] | {address: .address, tags_merged: (.values.tags_all + .values.tags)}]' > temp-tags.json

for resource in $(jq -r '.[] | @base64' temp-tags.json); do
    ADDRESS=$(echo "$resource" | base64 --decode | jq '.address')
    TAGS_MERGED=$(echo "$resource" | base64 --decode | jq '.tags_merged')
    if [[ "$TAGS_MERGED" != "null" ]]; then
        PAYLOAD=$(echo "$PAYLOAD" | jq "(.planned_values.root_module.resources[] | select(.address==$ADDRESS).values.tags)=$TAGS_MERGED")
    fi
done

rm temp-tags.json
echo $PAYLOAD | jq . > "$1"

# Child Modules
if [[ $(jq -r '.planned_values.root_module.child_modules | length' $1) -gt 0 ]] ; then
    echo $PAYLOAD | jq -c '[.planned_values.root_module.child_modules[].resources[] | {address: .address, tags_merged: (.values.tags_all + .values.tags)}]' > temp-tags.json

    if [[ $(jq length temp-tags.json) -gt 0 ]] ; then
        for resource in $(jq -r '.[] | @base64' temp-tags.json); do
            ADDRESS=$(echo "$resource" | base64 --decode | jq '.address')
            TAGS_MERGED=$(echo "$resource" | base64 --decode | jq '.tags_merged')
            if [[ "$TAGS_MERGED" != "null" ]]; then
                PAYLOAD=$(echo "$PAYLOAD" | jq "(.planned_values.root_module.child_modules[].resources[] | select(.address==$ADDRESS).values.tags)=$TAGS_MERGED")
            fi
        done

        echo $PAYLOAD | jq . > "$1"
    fi
    rm temp-tags.json
fi

# GrandChild Modules
if [[ -z $(jq -r '.planned_values.root_module.child_modules[].resources[].child_modules | length' $1) ]] ; then
    echo $PAYLOAD | jq -c '[.planned_values.root_module.child_modules[].resources[].child_modules[].resources[] | {address: .address, tags_merged: (.values.tags_all + .values.tags)}]' > temp-tags.json

    if [[ $(jq length temp-tags.json) -gt 0 ]] ; then
        for resource in $(jq -r '.[] | @base64' temp-tags.json); do
            ADDRESS=$(echo "$resource" | base64 --decode | jq '.address')
            TAGS_MERGED=$(echo "$resource" | base64 --decode | jq '.tags_merged')
            if [[ "$TAGS_MERGED" != "null" ]]; then
                PAYLOAD=$(echo "$PAYLOAD" | jq "(.planned_values.root_module.child_modules[].resources[].child_modules[].resources[] | select(.address==$ADDRESS).values.tags)=$TAGS_MERGED")
            fi
        done

        echo $PAYLOAD | jq . > "$1"
    fi

    rm temp-tags.json
fi