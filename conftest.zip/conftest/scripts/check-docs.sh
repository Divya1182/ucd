#!/bin/bash
set -o nounset -o errexit -o pipefail

GREEN='\033[0;32m'
ORANGE='\033[0;33m'
NC='\033[0m'

# Quick test that checks if markdown documentation is written.
for rule_folder in terraform/*/*; do
    baseRuleFolder="$(basename $rule_folder)"
    if [[ $(dirname $rule_folder) != "terraform/utilities" ]] ; then
        if [[ $(find docs/* -name "$baseRuleFolder.md") ]]; then
            echo "Found $baseRuleFolder.md"
        else
            echo -e "${ORANGE}> Missing: $baseRuleFolder.md${NC}"
            exit 1
        fi
    fi
done

# Step for docker rules,
for rule_folder in rules/docker/*; do
    baseRuleFolder="$(basename $rule_folder)"
    if [[ $(find docs/* -name "$baseRuleFolder.md") ]]; then
            echo "Found $baseRuleFolder.md"
    else
        echo -e "${ORANGE}> Missing: $baseRuleFolder.md${NC}"
        exit 1
    fi
done

echo -e "${GREEN}> All rules have an associated markdown documentation.${NC}"

