#!/bin/bash
set -o nounset -o errexit -o pipefail

# Quick test that checks file naming.

for rule_file in terraform/*/*/*.rego; do
  1>&2 echo "Checking $rule_file..."
  if [[ $(dirname $(dirname $rule_file)) == "terraform/utilities" || $(dirname $(dirname $rule_file)) == "terraform/shared-functions" ]] ; then
    break
  fi

  test_file="test-files/$(dirname "$rule_file")/$(basename "$rule_file" .rego)_test.rego"
  if [[ ! -f "$test_file" ]]; then
    1>&2 echo "Missing $test_file"
    exit 1
  fi

  terraf_file="test-files/$(dirname "$rule_file")/$(basename "$rule_file" .rego).tf"
  if [[ ! -f "$terraf_file" ]]; then
    1>&2 echo "Missing $terraf_file"
    exit 1
  fi
done

for rule_file in rules/*/*/*.rego; do
  1>&2 echo "Checking $rule_file..."
  test_file="test-files/$(dirname "${rule_file#rules/}")/$(basename "$rule_file" .rego)_test.rego"

  if [[ ! -f "$test_file" ]]; then
    1>&2 echo "Missing $test_file"
    exit 1
  fi

  docker_file_valid="test-files/$(dirname "${rule_file#rules/}")/$(basename "$rule_file" .rego)_valid.Dockerfile"
  docker_file_invalid="test-files/$(dirname "${rule_file#rules/}")/$(basename "$rule_file" .rego)_invalid.Dockerfile"

  if [[ ! -f "${docker_file_valid}" ]]; then
    1>&2 echo "Missing $docker_file_valid"
    exit 1
  elif [[ ! -f "${docker_file_invalid}" ]] ; then
    1>&2 echo "Missing $docker_file_invalid"
    exit 1
  fi
done

1>&2 echo "All rego files have corresponding test and terraform/docker files!"
