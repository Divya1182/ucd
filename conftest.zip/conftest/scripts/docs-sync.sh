#!/bin/bash
set -o nounset -o errexit -o pipefail

GREEN='\033[0;32m'
ORANGE='\033[0;33m'
NC='\033[0m'

# Find only newly changed doc files
git fetch origin
filesDiff=$(git diff $(git describe --abbrev=0 --tags $CI_COMMIT_TAG^)..$CI_COMMIT_TAG --name-only | grep -e "^docs\/\w*\/.*\.md$")

# Sync markdown files with Confluence
for file in $filesDiff; do
    filename=$(basename $file)
    1>&2 echo -e "${ORANGE}> Sync $filename ${NC}";
    mark -u ${K8S_SECRET_MARK_USER} -p ${K8S_SECRET_MARK_PASS} -b ${MARK_URL} -f $file || exit 1;

done

1>&2 echo -e "${GREEN}> All markdown files under docs folder have been synced up with Confluence!${NC}"