Conftest - Policy As Code
============

Leverages Open Policy Agent (OPA) to scan configuration files (k8s,terraform,yaml)

Terraform and Dockerfiles are currently supported. Policies will be managed in this repo and leverage the "pull" feature of conftest to be shared



## Useful Links
- https://www.openpolicyagent.org/docs/latest/
- https://www.openpolicyagent.org/docs/latest/terraform/
- https://github.com/open-policy-agent/conftest/
- https://github.com/fugue/regula (OPA terraform parsing library)
- https://github.com/fugue/fregot (OPA debugger)

## Policy Checker Board
To examine the policy checkers that have been implemented in this repository, follow this link: [https://confluence.sys.cigna.com/display/CLOUD/Policy+Checker+Board](https://confluence.sys.cigna.com/display/CLOUD/Policy+Checker+Board)

## Walkthrough
To set up your machine locally to run terraform plans with Conftest, follow this link: [https://confluence.sys.cigna.com/display/CLOUD/Where+to+Start+with+Conftest](https://confluence.sys.cigna.com/display/CLOUD/Where+to+Start+with+Conftest)

## Development Guide
To learn more about Conftest and how the Cigna development team utilizies the open-source policy engine, read through our [development guide](./Development.md).

## Contributor Guide
If you are looking to contribute to the Conftest Cigna project, take a look at the [contributor guide](./Contributing.md) to understand how the team creates new compliance rules for this repository.

## Consuming this library

If you are scanning terraform files please see the section below. This section applies to all other file formats

The following command will place the rego rules into a directory called ``policy`` in the directory it is run from. It will then validate the plan. It will only download if the files have changed 

``conftest test --update "git::https://git.sys.cigna.com/cloud-sec-eng/conftest.git//rules?ref=<tagged-version>" <your-file here>``

You can override the location the rules are stored with path option below. This should be useful for caching

``conftest test -p test/ --update "git::https://git.sys.cigna.com/cloud-sec-eng/conftest.git//rules?ref=<tagged-version>" <your-file here>``

To see available tags please click on Respository > Tags on the left menu

## Consuming this library (Terraform)

Running conftest against terraform requires that a plan be generated. Please note the alternate folder path 
### Generating the terraform plan json

``terraform init``

``terraform plan -out tf-plan.binary ``

``terraform show -json tf-plan.binary > tf-plan.json``

The command structure remains the same but uses a different directory in the repository (terraform vs rules). The terraform directory will be moved to the rules directory in a future release

``conftest test --update "git::https://git.sys.cigna.com/cloud-sec-eng/conftest.git//terraform?ref=<tagged-version>" tf-plan.json``
#### Using terraform Default Tags

If you are using terraform [default tags](https://www.hashicorp.com/blog/default-tags-in-the-terraform-aws-provider) functionality, you may encounter issues running conftest against your terraform json.  There is a script in this repo that you can use that will merge default tags with resource specific tags.  Example below:

``curl https://git.sys.cigna.com/cloud-sec-eng/conftest/-/raw/master/scripts/merge-tf-all-tags.sh | bash -s -- tf-plan.json``
### How to Use Exceptions

When using exceptions with conftest, the test command can be modified to the following format

``conftest test -p policy -p exceptions --update "git::https://git.sys.cigna.com/cloud-sec-eng/conftest.git//terraform?ref=<tagged-version>" tf-plan.json``

The additional ``-p`` argument would be used to specify the path to an additonal directory which houses the necessary file

A sample ``config.rego`` can be seen below. Multiple rules can be specified

```
package main

exception[rules] {
 rules := ["non_quay_images"]
}
```
### How to Use Exceptions (Terraform)

For Terraform, We're using regula's (a library we use to parse Terraform) exception approach for this which is covered [here](https://github.com/fugue/regula#waiving-rule-results)

The terraform exception also can leverage an additional directory in the same way the general conftest approach does. The format of the config.rego file would switch to something similar to what is shown below. Full details of supported parameters are provided in the above link

```
package fugue.regula.config

waivers[waiver] {
    waiver := {
        "rule_name": "minimum_required_tags",
    } 
} {    
    waiver := {
        "rule_name": "asaq_id_validation",
    }
} {    
    waiver := {
        "rule_name": "asset_owner_validation",
    }
}
```

### Known Issues that require exceptions

Certain Resource Types will not populate fields that are being checked by some rules on the first create for those particular resources, however on subsequent changes/updates will be present in the Terraform plan.

For these use cases we suggest utilizing exceptions as documented above for the first deploy.
The following list is instances we are currently aware of where this would be necessary:
```
First deploy of certain modules that contain tags as input variables (such as KMS Keys). This can cause a false positive for the minimum tagging standard rule.  

First deploy of a Backup vault policy. This can cause a false positive for the Backup vault policy restricted principal rule
```