Running this example
============

Files provided
- test.tf (resources to be scanned)
- tf-plan.json (json representation of plan, see below)
- policy/deny.rego (policy to evaluate against)

The terraform plan has been provided for you, but the following steps can be used to generate against your own terraform directories.

``terraform plan -out tf-plan.binary ``


``terraform show -json tf-plan.binary > tf-plan.json``


To evaluate you would then run

``conftest test tf-plan.json``