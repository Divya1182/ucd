# Contributing

Thanks for your interest in contributing to the Conftest project at Cigna!

# Where to start?

If you have questions, comments, or requests feel free to post in the [Policy-as-Code Mattermost channel](https://mm.sys.cigna.com/cloud-ops-guild/channels/policy-as-code).

If you want to contribute code and you are new to the Rego programming language, check out
the [DEVELOPMENT.md](./Development.md) reference for help getting started.

We have also created documentation on Confluence to help individuals get started with setup, creation of rules and testing against Terraform. Check out [https://confluence.sys.cigna.com/display/CLOUD/Documentation](https://confluence.sys.cigna.com/display/CLOUD/Documentation).

We currently welcome contributions of all kinds. For example:

- Development of features, bug fixes, and other improvements.
- Documentation including reference material and examples.
- Bug and feature reports.

# Local Testing

In order to run policies and their test files locally, you can follow the below instructions.  Local testing is useful for development purposes.  See the instructions below:

## Run policies locally

1. Create a folder for your service you are testing in Conftest.  For example, create a folder called `./s3/`.  This will be a file you can delete when the policy is finished.  
2. Within this folder, create the following folder structure:
```
s3/
    policy/ 
        utilities/**
        my_new_s3_policy.rego
        regula.rego
    my_new_s3_policy.tf
    plan.json
```
Notes:
    - You can get the utilities/ folder and all the contents from `./terraform/utilities`
    - You can transform the `my_new_s3_policy.tf` to `plan.json` with the following commands:
        - `terraform init`
        - `aws-fed login <enter any account>`
        - `terraform plan -out plan.binary`
        - `terraform show -json plan.binary > plan.json`
3. Navigate the terminal to the s3 folder
    - `cd s3`
4. From here you can apply your policy on the `plan.json` you have created
    - `conftest test plan.json`
    - Conftest will automatically get the `my_new_s3_policy.rego` policy and apply it to the plan.json

## Run tests locally

1. Continue to use the `./s3/` folder
2. Within the folder, create the following folder structure:
```
s3/
    policy/ 
        utilities/**
        my_new_s3_policy_test.rego
        my_new_s3_policy.rego
        regula.rego
```
Notes:
    - The `my_new_s3_policy_test.rego` file contains the code which tests `./terraform/aws/s3/my_new_s3_policy.rego`
3. Run the following command to run the test:
    - `opa test ./policy/`

## Common Errors

    - When the `opa test` command is run, you get an error that states `rego_unsafe_var_error: var pol is unsafe`
        - SOLUTION: The `my_policy_test.rego` file and the `my_policy.rego` file must be in the same package
        - [OPA Package Documentation](https://www.openpolicyagent.org/docs/latest/policy-language/#modules)

    - Where are print/log commands for debugging?!
        - SOLUTION: Add the below block of code to your `my_policy.rego` file where you deny resources to print out the objects contents
        ```
        #inside deny section
        msg = sprintf("Resource Info: %s",[resource]) 
        p = fugue.deny_resource_with_message(resource, msg)
        ```

    - When the `opa test` command is run, you get the error `eval_conflict_error: complete rules must not produce multiple outputs`
        - SOLUTION: You have two packages with the same name.  This is likely because an AWS policy has a package with the same name as an Azure policy you are working on, or vice versa.

Now you can see the results of the test and confirm that it runs as expected.

# Contribution process

Before submitting large changes like new compliance rules, please open an issue on GitLab outlining:

- Description of compliance rule
- Source of finding

Use your judgement about what constitutes a large change. If you aren't sure, send a message to the [Policy-as-Code Mattermost channel](https://mm.sys.cigna.com/cloud-ops-guild/channels/policy-as-code).

Most of the time, issues would have created based off Prisma alerts, NCC Group Findings or team investigation, so manual creation is not needed. If there is a compliance rule you want to tackle, assign the issue to your name and assign **Doing** label. Add any relevant information to the issue description. Tag Conftest team members to the discussion if questions arise.

## Code Contributions

If you are contributing code, please consider the following:

- Most changes should be accompanied with tests.
- All tests must pass (`opa test`).
- All rego files must be formatted (`opa fmt`).
- Terraform template/Dockerfile must be included in MR.
- Add/update markdown file inside /docs for Confluence Documentation
  - Ensure the rego policy folder name matches the name of the markdown file

If you are new to Rego, consider reading our [Confluence Documentation](https://confluence.sys.cigna.com/display/CLOUD/Documentation) and [OPA Documentation](https://www.openpolicyagent.org/docs/latest/) for guidance on writing Conftest Rules.

## Commit Messages

Commit messages should explain _why_ the changes were made and should probably look like this:

```
Description of the change in 50 characters or less
```

## Preparation for Merge Requests

### Confluence Documentation

To document the new compliance rule, you must update the confluence service policy page for the end user. The conftest service policy page will help end users understand why their pipelines are failing and how to fix the error codes. Here is an [example](https://confluence.sys.cigna.com/display/CLOUD/AWS+Conftest+Policies) of a Conftest service policy page.

The GitLab repository has a bash script to validate that policies for new services has a corresponding markdown file. The Conftest team want to ensure that every policy is documented in Confluence.

### File Naming Convention

To have a valid merge request, the following files must be pushed to the remote branch. The files names should be identical except for the test rego file. The correct naming convention can be found in the code block below.

```
~/terraform/*/<rule-name>.rego
~/test-files/*/<rule-name>.tf
~/test-files/*/<rule-name>_test.rego
```

### Rego Rule File

The rego rule file name should be identical to the conftest package rule name.
**Rego file name**

```
~/terraform/*/<rule-name>.rego
```

**Inside rego file**

```
package rules.<rule-name>
```

Write code documentation in the rego file to describe the functionality of all methods. If there is complicated logic being utilized, comment additional messages to explain the procedure.

Lastly, please include a link to the policy on confluence within your deny message.

### Rego Test File

The rego test file name should be similar to the conftest package rule name and the test method name.
**Rego test file name**

```
~/test-files/*/<rule-name>_test.rego
```

**Inside rego test file**

```
package test.rules.<rule-name>

import data.fugue.regula

test_<rule-name> {
  report := regula.report with input as mock_input
  resources := report.rules.<rule-name>.resources

  resources["testcase1.valid"].valid == true
  resources["testcase2.invalid"].valid == false

}
```

The rego test mock input should be a generated plan of the respective terraform template provided in the feature branch. This will help the developing team to recreate terraform plans when debugging rego files. For documentation, write the purpose of the test rego file in the first few lines. We want to specify the purpose of the test rego file so that if an end user stumbles upon the test file, they are not confused.

### Terraform File

For every terraform file, there should have an invalid and valid resource case, so that the test rego file has both cases. Write code documentation in the terraform file to specify which resources will pass and why. The correct comments can be found in the code block below.
**Invalid Test Case**

```
# INVALID: <reasoning for invalid case>
resource "aws_vpc" "invalid" {
    ...
}
```

**Valid Test Case**

```
# VALID: <reasoning for valid case>
resource "aws_vpc" "valid" {
    ...
}
```

## Merge Requests

Follow the merge request template to the best of your knowledge, so reviewers can understand new compliance rule or bug fixes.

If your changes are related to an open issue (bug or feature), please include the following line at the end of your merge request description:

```
Closes #<ISSUE_NUMBER>
```

Fill out Assignee, Milestone, and Labels to accurately track team members efforts. Milestone corresponds to the sprint associated with the work. Labels help the team track which compliance rules are for which cloud platform provider.

At the end of the merge request, check both boxes for deleting source branch and squashing commits.

- [x] Delete source branch when merge request is accepted.
- [x] Squash commits when merge request is accepted.

## Code Review

Before a Merge Request is merged, it will undergo code review from other members of the Conftest Cigna team. In order to streamline the code review process, when amending your Merge Request in response to a review, do not squash your changes into relevant commits until it has been approved for merge. This allows the reviewer to see what changes are new and removes the need to wade through code that has not been modified to search for a small change.

If your Merge Request is small though, it is acceptable to squash changes during the review process. Use your judgement about what constitutes a small Merge Request. If you aren't sure, send a message to the Policy-as-Code Mattermost channel.


## Code Mirroring

Currently Conftest is (manually) mirrored to github from gitlab to allow health services to access the library.

This is achieved by setting up a second remote locally on the git repo on your machine.
From there ensuring master is in sync and cutting tags/releases at the same time can occur.
The person taking this action must have enough permissions to push to master on Github
This will no longer be necessary once the full cutover to Github occurs (moving pipeline to jenkins)

Useful commands for the above
```
git add remote origin2 <https/ssh for repo>

git checkout master
git pull
git push origin2
```