## Development

Conftest is a tool to help you write tests against structured configuration data. Tests can be written for many configuration formats such as Kubernetes configurations, Tekton pipeline definitions or Terraform code. Conftest relies on the REPO language from Open Policy Agent for writing the assertions. Conftest framework puts structure around OPA which gives policy-as-code team many benefits. The return data from validate policy is easy to read to know how many tests were ran and which failed. Additionally, Conftest categorizes rules into deny, warn and violate actions to be easily integrated with pipelines.


If you are not familiar with OPA or Conftest, we recommend you read through the [Conftest Documentation](https://www.conftest.dev/) and [OPA Documentation](https://www.openpolicyagent.org/docs/latest/) to familiarize yourself with the standard OPA environment.

Requirements:

- Git
- GitLab account
- OPA
- Conftest
- AWS-FED (AWS CLI - SAML)
- AZ CLI
- Terraform
  
## Getting Started

1. Go to [https://git.sys.cigna.com/cloud-sec-eng/conftest](https://git.sys.cigna.com/cloud-sec-eng/conftest)

2. Clone the repository to your local machine.
    
    ```bash
    git clone https://git.sys.cigna.com/cloud-sec-eng/conftest.git
    ```

3. Create a branch for your changes.

    ```
    git checkout -b somefeature
    ```


4. Develop your changes and regularly update your local branch against upstream.

5. Commit changes and push to GitLab.

    ```
    git commit -m "some message"
    git push origin somefeature
    ```
   
   > Make sure to use a [good commit message](../Contributing.md#commit-messages)

6. Submit a Merge Request in GitLab Repostiory. 
   
    > Hint: You should be prompted to with a "Compare and Pull Request" button that mentions your new branch on [https://git.sys.cigna.com/cloud-sec-eng/conftest/merge_requests](https://git.sys.cigna.com/cloud-sec-eng/conftest/merge_requests)
