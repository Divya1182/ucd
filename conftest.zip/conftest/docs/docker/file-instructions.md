<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Dockerfile Conftest Policies -->
<!-- Title: File-instructions Policies -->
<!-- Layout: plain -->

 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Dockerfile file-instructions rules leverage Open Policy Agent (OPA) to scan Dockerfile configuration files and validate secure and efficient instructions. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                        | Rule Description                                                  | Conftest Rule                                                                                                                                                  | Dockerfile Test Cases                                                                                                                                                                                                                                                                                                                                               | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ----------------------------- | ----------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Add cmd**                   | Deny using the `ADD` command in favor of `COPY`.                  | [Add_cmd](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/rules/docker/file-instructions/add_cmd.rego)                                          | [Add_cmd_valid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/add_cmd_valid.Dockerfile) [Add_cmd_invalid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/add_cmd_invalid.Dockerfile)                                                 | deny      | v0.34                                                         |
| **Copy All cmd**              | Deny copying all files with `COPY ..` command                     | [Copy_all](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/rules/docker/file-instructions/copy_all.rego)                                        | [Copy_all_valid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/copy_all_valid.Dockerfile) [copy_all_invalid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/copy_all_invalid.Dockerfile)                                             | deny      | v0.33                                                         |
| **Deny Banned Ports**         | Deny the usage of ports under 1024 that are not 80 or 443         | [Expose_banned_ports](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/expose_banned_ports_valid.Dockerfile) | [Expose_banned_ports_valid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/expose_banned_ports_valid.Dockerfile) [expose_banned_ports_invalid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/expose_banned_ports_invalid.Dockerfile) | deny      | v0.33                                                         |
| **Require Dockerfile Labels** | Require Dockerfiles to have appropriate labeling                  | [Label_required](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/label_required_valid.Dockerfile)           | [label_required_valid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/label_required_valid_extra.Dockerfile) [label_required_invalid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/label_required_invalid.Dockerfile)               | deny      | v0.33                                                         |
| **Deny Root as Last User**    | Deny a Dockerfile building a container with Root as the last user | [User_last_not_root](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/rules/docker/file-instructions/user_last_not_root.rego)                    | [user_last_not_root_valid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/user_last_not_root_valid.Dockerfile) [user_last_not_root_invalid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/file-instructions/user_last_not_root_invalid.Dockerfile)     | deny      | v0.33                                                         |

<!-- More description of each rule, functionality  -->

## Deny ADD command in favor of COPY

The COPY command is the preferred method of the two because it is more transparent than the ADD command and has less risk. The ADD command allows for downloading data from remote URLs that could lead to man-in-the-middle-attacks or other security risks with zip file vulnerabilities.

## Deny COPY all via `COPY ..`

Using the COPY command to COPY files individually, rather than all at once, ensures that each step’s build cache is only invalidated (forcing the step to be re-run) if the specifically required files change.

## Deny Exposed Ports under 1024 except 80 or 443

Containers should be built with only the minimum necessary required ports to be open.

## Require Dockerfile Labels

Labeling containers is a beneficial practice for all parties as it provides important metadata of a containers owner and other key details that would not be easily obtainable otherwise.

## Deny Root user as Last User

It is extremely important for containers to run in rootless mode. Containers that allow users root level access introduces a major security risk that could lead to the entire comprise of the underlying node or cluster.

### Sources

- [1] - <cite>https://docs.docker.com/develop/develop-images/dockerfile_best-practices/#add-or-copy</cite>
- [2] - <cite>https://snyk.io/blog/10-docker-image-security-best-practices/</cite>
- [3] - <cite>https://blog.aquasec.com/docker-security-best-practices</cite>
