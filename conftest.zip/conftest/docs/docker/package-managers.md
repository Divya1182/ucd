<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Dockerfile Conftest Policies -->
<!-- Title: Package-manager Policies -->
<!-- Layout: plain -->

 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Dockerfile package-manager rules leverage Open Policy Agent (OPA) to scan Dockerfile configuration files to enforce best practices with 3rd party libraries and packages. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy              | Rule Description                                                            | Conftest Rule                                                                                                                        | Dockerfile Test Cases                                                                                                                                                                                                                                                                                                                             | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ------------------- | --------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Pip Artifactory** | Deny the installation of python packages that do not come from Artifactory. | [Pip_artifactory](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/rules/docker/package-managers/pip_artifactory.rego) | [Pip_artifactory_valid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/package-managers/pip_artifactory_valid.Dockerfile) [Pip_artifactory_invalid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/package-managers/pip_artifactory_invalid.Dockerfile) | deny      | v0.31                                                         |

<!-- More description of each rule, functionality  -->

## Pip install from Artifactory

Python packages should be installed onto containers from the internal trusted package manager [Artifactory](http://repo.sys.cigna.com/). Downloading python packages from external sources could introduce risk by installing unexpected package vulnerabilities into the container or lead to a supply chain attack.

Example usage:

- pip3 install --requirement requirements.txt --index-url https://repo.sys.cigna.com/artifactory/api/pypi/pypi-repos/simple --trusted-host repo.sys.cigna.com --target /packages/
