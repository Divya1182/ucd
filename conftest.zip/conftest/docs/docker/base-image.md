<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Dockerfile Conftest Policies -->
<!-- Title: Base-image Policies -->
<!-- Layout: plain -->

 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Dockerfile base-image rules leverage Open Policy Agent (OPA) to scan Dockerfile configuration files and validate different base image sources and versions. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                | Rule Description                                       | Conftest Rule                                                                                                            | Dockerfile Test Cases                                                                                                                                                                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| --------------------- | ------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Latest Image Tag**  | Deny using the Latest tag for base images permissions. | [latest usage](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/rules/docker/base-image/latest_usage.rego) | [latest_usage_valid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/base-image/latest_usage_valid.Dockerfile) [latest_usage_invalid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/base-image/latest_usage_invalid.Dockerfile) | deny      | v0.31                                                         |
| **Quay Image Source** | Deny using base images that do not originate from Quay | [Quay Image](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/rules/docker/base-image/quay_image.rego)     | [quay_image_valid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/base-image/quay_image_valid.Dockerfile) [quay_image_invalid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/base-image/quay_image_invalid.Dockerfile)         | deny      | v0.31                                                         |

<!-- More description of each rule, functionality  -->

## Latest Image tag

Dockerfiles utilizing a base-image via the `:latest` tag are subject to unintended changes that are published to the latest version of that base image. Using an immutable image tag like `:1.3` prevents unintended changes from affecting the performance and security of your container.

## Quay Image Source

Dockerfiles utilizing base-images from untrustworthy sources inherit risks that could be mitigated from using base-images from our internal Quay repositories. Base-images from untrustworthy sources cannot be verified to be secure and can contain malware or vulnerable components.
