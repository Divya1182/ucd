<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Dockerfile Conftest Policies -->
<!-- Title: Run-command Policies -->
<!-- Layout: plain -->

 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Dockerfile run-command rules leverage Open Policy Agent (OPA) to scan Dockerfile configuration files to enforce best practices when construction Dockefiles. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy            | Rule Description                                                                            | Conftest Rule                                                                                                                | Dockerfile Test Cases                                                                                                                                                                                                                                                                                                             | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ----------------- | ------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Chmod usage**   | Deny running `chmod` in a way that grants unsafe global read, write and execute permissions | [Chmod_rwx](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/rules/docker/run-commands/chmod_rwx.rego)         | [Chmod_valid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/run-commands/chmod_rwx_valid.Dockerfile) [Chmod_invalid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/run-commands/chmod_rwx_invalid.Dockerfile)                         | deny      | v0.31                                                         |
| **Contains Sudo** | Deny the use of `sudo` inside `RUN` commands as it can lead to unexpected behavior.         | [Contains_sudo](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/rules/docker/run-commands/contains_sudo.rego) | [Contains_sudo_valid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/run-commands/contains_sudo_valid.Dockerfile) [Contains_sudo_invalid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/run-commands/contains_sudo_invalid.Dockerfile) | deny      | v0.31                                                         |
| **Curl Bashing**  | Deny curl bashing as it is an unsafe operation.                                             | [Curl_bashing](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/rules/docker/run-commands/curl_bashing.rego)   | [Curl_bashing_valid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/run-commands/curl_bashing_valid.Dockerfile) [Curl_bashing_invalid.Dockerfile](https://git.sys.cigna.com/cloud-sec-eng/conftest/-/blob/master/test-files/docker/run-commands/curl_bashing_invalid.Dockerfile)     | deny      | v0.31                                                         |

<!-- More description of each rule, functionality  -->

## Chmod Usage

Excessive usage of Chmod introduces a security risk when allowing any user to modify, execute and write to the files affected by the Chmod. An unauthorized user could use this to modify files to compromise the container.

## RUN command containing Sudo

Dockerfiles should employ the principle of least privilege. Avoid using root in RUN commands altogether to not introduce unneeded security risks.

## Curl Bashing

Using `curl <url> | bash` is an unsafe operating that should be avoided.
