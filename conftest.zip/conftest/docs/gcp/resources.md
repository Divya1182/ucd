<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: GCP Conftest Policies -->
<!-- Title: Multi-Resource Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following Resource conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate the Google provider. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about supported resources visit [GCP Resource Information](https://confluence.sys.cigna.com/display/CLOUD/GCP+Services)



## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**Allowed Resources**|Deny Resources that are not in the supported list .| [allowed_gcp_resources](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/gcp/resources/allowed_gcp_resources.rego)|[allowed_gcp_resources.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/gcp/resources/allowed_gcp_resources.tf)|deny|v0.37|


<!-- More description of each rule, functionality  -->
## Allowed Resources
Only supported resources should be utilized and deployed. Not every resource is supported. Please see the resource information page mentioned above for more details on the maturity of the resources.
