<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: CloudFormation Conftest Policies -->
<!-- Layout: plain -->


 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Cloudformation conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_cloudformation_stack resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about CloudFormation visit [CloudFormation](https://aws.amazon.com/cloudformation/)

<!-- Add link to Service Policy page -->
View all Cloud Formation policies on [CloudFormation Policy](https://confluence.sys.cigna.com/display/CLOUD/CloudFormation+Conftest+Policies).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**CloudFormation AppFlow Salesforce Connector KMS Encrypted**|Deny CloudFormation templates that has AppFlow Salesforce Connectors that does not have valid KMS keys | [cloudformation_appflow_salesforce](https://git.sys.cigna.com/cigna/conftest/blob/master/terraform/aws/cloudformation/cloudformation_appflow_salesforce.rego)|[cloudformation_appflow_salesforce_test.tf](https://git.sys.cigna.com/cigna/conftest/blob/master/test-files/terraform/aws/cloudformation/cloudformation_appflow_salesforce_test.tf)|deny|v0.44|

<!-- More description of each rule, functionality  -->
## CloudFormation AppFlow Salesforce Connector KMS Encrypted
AppFlow is being used to sync data from external third party cloud like Salesforce. AppFlow Connectors can be configured using Cloudformation templates. This rules makes sure that the connector configuration for salesforce has valid KMS keys in it  


