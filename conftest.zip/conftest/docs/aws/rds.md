<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: RDS Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following RDS conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_db_instance/aws_rds_cluster resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about RDS visit [Relational Database Service (RDS)](https://confluence.sys.cigna.com/display/CLOUD/RDS)

<!-- Add link to Service Policy page -->
View all RDS policies on [RDS Policy](https://confluence.sys.cigna.com/display/CLOUD/RDS+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy                             | Rule Description                                                                        | Conftest Rule                                                                                                                                    | Terraform Cases                                                                                                                                              | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------------------- | --------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------ | --------- | ------------------------------------------------------------- |
| **RDS Auto Minor Version Upgrade** | Deny all RDS instances with auto minor version upgrade set to false.                    | [rds_auto_minor_version_upgrade](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/rds/rds_auto_minor_version_upgrade.rego) | [rds_auto_minor_version_upgrade.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/rds/rds_auto_minor_version_upgrade.tf) | deny      | v0.6                                                          |
| **RDS Encryption**                 | Deny RDS instances and clusters that are not encrypted.                                 | [rds_encryption](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/rds/rds_encryption.rego)                                 | [rds_encryption.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/documentation-demo/test-files/terraform/aws/rds/rds_encryption.tf)                     | deny      | v0.5                                                          |
| **RDS Multi-AZ**                   | Deny RDS instances that are not replicating data to a standby instance across AZs.      | [rds_multi_az](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/rds/rds_multi_az.rego)                                     | [rds_multi_az.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/documentation-demo/test-files/terraform/aws/rds/rds_multi_az.tf)                         | deny      | v0.5                                                          |
| **RDS Retention**                  | Deny RDS instances and clusters that do not have a retention policy of at least 7 days. | [rds_retention](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/rds/rds_retention.rego)                                   | [rds_retention.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/documentation-demo/test-files/terraform/aws/rds/rds_retention.tf)                       | deny      | v0.5 
| **RDS Publicly Accessible**                  | Deny RDS instances and cluster instances that are publicly accessible. | [rds_publicly_accessible](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/rds/rds_publicly_accessible.rego)                                   | [rds_publicly_accessible.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/documentation-demo/test-files/terraform/aws/rds/rds_publicly_accessible.tf)                       | deny      | v0.28                                                         |
| **RDS Proxy Debug Logging**        | Deny RDS proxies that have debug logging enabled. | [rds_proxy_debug_logging](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/rds/rds_proxy_debug_logging.rego)                                   | [rds_proxy_debug_logging.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/documentation-demo/test-files/terraform/aws/rds/rds_proxy_debug_loggings.tf)                       | deny      | v0.31                                                         |
| **RDS Proxy IAM Authentication**   | Deny RDS proxies that have not enabled IAM authenticaton between application and proxy. | [rds_proxy_iam_auth](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/rds/rds_proxy_iam_auth.rego)                                   | [rds_proxy_iam_auth.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/documentation-demo/test-files/terraform/aws/rds/rds_proxy_iam_auth.tf)                       | deny      | v0.31                                                         |
| **RDS Proxy Idle Client Timeout**  | Deny RDS proxies that have idle client timeout less than 1 min or more than 1 hour. | [rds_proxy_idle_client_timeout](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/rds/rds_proxy_idle_client_timeout.rego)                                   | [rds_proxy_idle_client_timeout.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/documentation-demo/test-files/terraform/aws/rds/rds_proxy_idle_client_timeout.tf)                       | deny      | v0.31                                                         |
| **RDS Proxy Multi AZ**             | Deny RDS proxies that are not multi-az enabled. | [rds_proxy_multi_az](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/rds/rds_proxy_multi_az.rego)                                   | [rds_proxy_multi_az.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/documentation-demo/test-files/terraform/aws/rds/rds_proxy_multi_az.tf)                       | deny      | v0.31                                                         |
| **RDS Proxy Require TLS**          | Deny RDS proxies that don't require TLS encryption. | [rds_proxy_require_tls](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/rds/rds_proxy_require_tls.rego)                                   | [rds_proxy_require_tls.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/documentation-demo/test-files/terraform/aws/rds/rds_proxy_require_tls.tf)                       | deny      | v0.31                                                         |
| **RDS Proxy Security Groups**      | Deny RDS proxies that haven't configured security groups. | [rds_proxy_security_groups](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/rds/rds_proxy_security_groups.rego)                                   | [rds_proxy_security_groups.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/documentation-demo/test-files/terraform/aws/rds/rds_proxy_security_groups.tf)                       | deny      | v0.31                                                         |

<!-- More description of each rule, functionality  -->
## RDS Auto Minor Version Upgrade
RDS auto minor version upgrade helps mitigate security risks, bugs, and data corruption problems from older minor versions. Although AWS frequently upgrades RDS version, the auto minor version upgrade takes a least impactful approach. 

## RDS Encryption
Amazon RDS encrypted DB instances use the industry standard AES-256 encryption algorithm to encrypt data on the server that hosts the Amazon RDS DB instances. By default, data stored in RDS instances are not encrypted.

## RDS Multi-AZ
To avoid data loss in RDS instances, multiple availabily zone provides an enhanced, highly-available database. When an rds database is provisioned with Multi-AZ enabled, Amazon RDS automatically creates a primary DB Instance and synchronously replicates the data to a standby instance in a different Availability Zone (AZ). In case of an infrastructure failure, Amazon RDS performs an automatic failover to the standby. By default, the multi-az option is disabled as it incurs additional cost. The following engines do not require multi-az to be enabled as its built-in: SqlServer, DocumentDB, and AuroraDB.

## RDS Retention
Amazon RDS retains backups of a DB Instance for a limited, user-specified period of time called the retention period, which by default is 7 days but can be set to up to 35 days. To prevent data loss, RDS retention backup period is recommended to be at least 7 days.

## RDS Publicly Accessible
Amazon RDS allows for RDS instances and RDS cluster instances to be made publicly accessible by setting the publicly_accessible flag to 'true'. Setting this to false will help prevent unauthorized access to your database.

## RDS Proxy Debug Logging
Amazon RDS Proxy allows to enable enhanced logging temporarily for operations purposes. The logs will include SQL statements which could contain senstive data. Adequate security measures must be taken to enable enhanced logging. RDS Proxy automatically disabled enhanced logging after 24 hours. Hence debug logging should not be enabled via terraform.

## RDS IAM Authentication
Amazon RDS has certain limitations if applications use IAM authentication when communicating directly with RDS. However, those limitations are not applicable when using IAM authentication between application and RDS Proxy since RDS Proxy will use password based authentication when connecting to RDS. Hence IAM authentication should be preferred over embedding database credentials in application code.

## RDS Idle Client Timeout
RDS Proxy periodically disconnects idle connections and returns them to the connection pool. You can adjust this timeout interval. Doing so helps your applications to deal with stale resources, especially if the application mistakenly leaves a connection open while holding important database resources. To prevent opening new connections too frequently or leaving connections open for too long, idle client timeout must be between 1 to 60 mins.

## RDS Proxy Multi AZ
Amazon RDS Proxy must be configured for high availability. This would allow for fast failover when an AZ goes down. Hence RDS Proxy must be configured with at least 2 subnets.

## RDS Proxy Require TLS
As a security best practice, data must be encrypted in transit to prevent unauthorized actors from gaining access to the data. Hence 'Require TLS' setting must be enabled.

## RDS Proxy Security Groups
A Security Group acts as a virtual firewall for your instance to control inbound and outbound traffic. If security group is not provided explicitly, RDS Proxy will use default security group of the VPC, which could be overly permissive. Hence security group(s) must be provided to restrict access to RDS Proxy.

<!-- Add Bucket Tagging Policy reference if service is included in tagging validation  -->
## RDS Instance Tagging
Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

