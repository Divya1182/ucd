<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: Lambda Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following Lambda conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_lambda_function resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about Lambda visit [Lambda Functions](https://confluence.sys.cigna.com/display/CLOUD/Lambda)

<!-- Add link to Service Policy page -->
View all Lambda policies on [Lambda Policy](https://confluence.sys.cigna.com/display/CLOUD/Lambda+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**Lambda Invoke Role**|Deny all Lambda functions that have LambdaInvoke action inside the attached role policy.| [lambda_invoke_role](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/lambda/lambda_invoke_role.rego)|[lambda_invoke_role.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/lambda/lambda_invoke_role.tf)|deny|v0.11|
|**Lambda Restricted Principal**|Deny all Lambda Permissions that are publicly accessible.| [lambda_permission_principal_star](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/lambda/lambda_permission_principal_star.rego)|[lambda_permission_principal_star.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/lambda/lambda_permission_principal_star.tf)|deny|v0.30|

<!-- More description of each rule, functionality  -->
## Lambda Invoke Role
The attached roles to Lambda functions should not have the ability to invoke any Lambda functions. Avoid chaining Lambda functions to make error handling easier downstream.

## Lambda Restricted Principal
Lambda Permissions should not be open to any principal to take an action on a Lambda Function. The principal for a Lambda Permission should be scoped to an AWS Account ID or a valid Service Principal.

<!-- Add Bucket Tagging Policy reference if service is included in tagging validation  -->
## Lambda Tagging
Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

