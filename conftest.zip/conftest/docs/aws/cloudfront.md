<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: CloudFront Conftest Policies -->
<!-- Layout: plain -->


 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following CloudFront conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_cloudfront_distribution resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about CloudFront visit [CloudFront](https://confluence.sys.cigna.com/display/CLOUD/CloudFront)

<!-- Add link to Service Policy page -->
View all API Gateway policies on [CloudFront Policy](https://confluence.sys.cigna.com/display/CLOUD/CloudFront+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**CloudFront HTTPS Enabled**|Deny CloudFront Distributions that allow access to content via HTTP | [cloudfront_https](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/cloudfront/cloudfront_https.rego)|[cloudfront_https.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/cloudfront/cloudfront_https.tf)|deny|v0.5|
|**CloudFront Centrally Logged**|Deny CloudFront Distributions that do not have logging enabled to the central bucket | [cloudfront_logging](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/cloudfront/cloudfront_logging.rego)|[cloudfront_logging.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/cloudfront/cloudfront_logging.tf)|deny|v0.8|
|**CloudFront TLS Versioning**|Deny CloudFront Distributions that do not use TLSv1.2_* or higher | [cloudfront_distribution_tls](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/cloudfront/cloudfront_distribution_tls.rego)|[cloudfront_distribution_tls.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/cloudfront/cloudfront_distribution_tls.tf)|deny|v0.11|

<!-- More description of each rule, functionality  -->
## CloudFront HTTPS
CloudFront distributions can define in the configuration what protocols are permitted when viewers access content in CloudFront edge locations. This policy denies any protocol that could allow access via HTTP, and looks for HTTPS or Redirect-to-HTTPS in the Viewer Protocol Policy

## CloudFront Logging
CloudFront has the ability to create log files that contain detailed information about every user request that CloudFront receives. We want to centrally log this information. This policy denies any configuration that does not contain a logging_config or any configuration that is not centrally logging to centralizedlogging-cigna-crossaccts3.s3.amazonaws.com.

## CloudFront Distribution TLS
CloudFront distributions can define in the configuration what ssl protocols are permitted for communication between the distribution and end user. This policy denies any ssl protocol that is lower than TLSv1.2_* or lower. TLSv1.1 and lower are considered deprecated and should not be used. TLSv1.2 or TLSv1.3 is considered more secure.

