<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: Sagemaker Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following Sagemaker conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate ``aws_sagemaker_*`` resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about Sagemaker visit [the service page](https://confluence.sys.cigna.com/display/CLOUD/SageMaker)

<!-- Add link to Service Policy page -->
View all Sagemaker policies on [Sagemaker Policy](https://confluence.sys.cigna.com/display/CLOUD/Sagemaker+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**Sagemaker Endpoint Encryption**|Deny Sagemaker endpoints that are not encrypted| [sagemaker_endpoint_encryption](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/sagemaker/sagemaker_endpoint_encryption.rego)|[sagemaker_endpoint_encryption.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/sagemaker/sagemaker_endpoint_encryption.tf)|deny|v0.8|
|**Sagemaker Notebook Encryption**|Deny Sagemaker notebooks that are not encrypted| [sagemaker_notebook_encryption](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/sagemaker/sagemaker_notebook_encryption.rego)|[sagemaker_notebook_encryption.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/sagemaker/sagemaker_notebook_encryption.tf)|deny|v0.8|
|**Sagemaker Notebook Direct Internet Access**|Deny Sagemaker notebooks that have direct internet access.| [sagemaker_notebook_internet_access](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/sagemaker/sagemaker_notebook_internet_access.rego)|[sagemaker_notebook_internet_access.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/sagemaker/sagemaker_notebook_internet_access.tf)|deny|v0.11|

<!-- More description of each rule, functionality  -->
## Sagemaker Endpoint Encryption
Sagemaker endpoints include storage that should be encrypted at rest. This is identified by if the ``kms_key_arn`` atrribute is set.
When not set the rule will fail.

## Sagemaker Notebook Encryption
Sagemaker notebooks include storage that should be encrypted at rest. This is identified by if the ``kms_key_id`` atrribute is set.
When not set the rule will fail.

## Sagemaker Notebook Direct Internet Access
Sagemaker notebooks are enabled for direct internet access by default. When an AWS SageMaker notebook instances are publicly accessible, any machine outside the VPC can establish a connection to these instances, increasing the attack surface and the opportunity for malicious activity.


<!-- Add Bucket Tagging Policy reference if service is included in tagging validation  -->
## Sagemaker Tagging
Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

