<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: IAM Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following IAM conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate different aws_iam_policy types, aws_iam_policy attachments, and aws_iam_role resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about IAM visit [Identity and Access Management (IAM)](https://confluence.sys.cigna.com/display/CLOUD/IAM)

<!-- Add link to Service Policy page -->
View all IAM policies on [IAM Policy](https://confluence.sys.cigna.com/display/CLOUD/IAM+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**IAM Admin Policy**|Deny full administrative permissions.| [iam_admin_policy](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/iam/iam_admin_policy.rego)|[iam_admin_policy.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/iam/iam_admin_policy.tf)|deny|v0.1|
|**IAM Deny NotActions**|Deny policies that grant permissions using deny-list approach.| [iam_deny_notactions](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/iam/iam_deny_notactions.rego)|[iam_deny_notactions.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/iam/iam_deny_notactions.tf)|deny|v0.8|
|**IAM Federated Role Name**|Deny IAM federated roles (identified by trust policy) when the name is not capitalized.| [iam_federated_role_name](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/iam/iam_federated_role_name.rego)|[iam_federated_role_name.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/iam/iam_federated_role_name.tf)|deny|v0.7|
|**IAM Permissive Policy Attachments**|Deny IAM managed policies that are overly permissive.| [iam_permissive_policy_attachment](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/iam/iam_permissive_policy_attachment.rego)|[iam_permissive_policy_attachment.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/iam/iam_permissive_policy_attachment.tf)|deny|v0.1|
|**IAM Policy Naming Standards**|Deny policies that do not follow policy naming standards.| [iam_policy_name](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/iam/iam_policy_name.rego)|[iam_policy_name.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/iam/iam_policy_name.tf)|deny|v0.7|
|**IAM Role Naming Standards**|Deny roles that do not follow role naming standards.| [iam_role_name](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/iam/iam_role_name.rego)|[iam_role_name.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/iam/iam_role_name.tf)|deny|v0.2|
|**IAM Role Types**|Deny IAM roles that have more than one role type.| [iam_role_type](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/iam/iam_role_type.rego)|[iam_role_type.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/iam/iam_role_type.tf)|deny|v0.7|
|**IAM Service Star Policy**|Deny IAM policies that use the wildcard attribute with service actions.| [iam_star](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/iam/iam_star.rego)|[iam_star.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/iam/iam_star.tf)|deny|v0.1|
|**IAM Resource Star Policy**|Deny policies that permits powerful actions and uses a wildcard attribute for resource| [iam_star_resource_policy](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/iam/iam_star_resource_policy.rego)|[iam_star_resource_policy.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/iam/iam_star_resource_policy.tf)|deny|v0.1|
|**IAM User Creation**|Deny the creation of all IAM Users.| [iam_user_creation](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/iam/iam_user_creation.rego)|[iam_user_creation.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/iam/iam_user_creation.tf)|deny|v0.11|
|**IAM Policy Document Principal Star**|Deny the creation of IAM Policy Documents that set Principal to a wildcard with no limiting condition.| [iam_policy_document_principal_star](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/iam/iam_policy_document_principal_star.rego)|[iam_user_creation.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/iam/iam_user_creation.tf)|deny|v0.25|

<!-- More description of each rule, functionality  -->
## IAM Admin Policy
IAM policies should not have administrator permissions (i.e. privileged users) this is in order to adhere to IAM security best practices and implement the principle of least privilege. This rule denies any type of IAM policy that grants full administrative permissions by validating and ensuring the policy is not a wildcard policy.

## IAM Deny NotActions
NotAction is an advanced policy element that explicitly matches everything except the specified list of actions. This rule denies any type of IAM policy that grant permissions using deny-list approach by validating and ensuring the policy does not contain NotAction Elements.


## IAM Federated Role Name
Role Name field should be all uppercase letters. This rule denies IAM federated roles if the role name is not capitalized by validating and ensuring the name is capitalized.


## IAM Permissive Policy Attachments
IAM policies should adhere to the principle of least privilege by giving the roles the minimal set of actions required to perform their tasks successfully. This rule denies any type of IAM policy attachments that overly permissive by validating and ensuring AWS managed policies that are too permissive are not used.

## IAM Policy Naming Standards
IAM policy names should not contain forbidden words. This rule denies any type of IAM policy that does not follow policy naming standards by validating and ensuring the policy name does not contain any of the following words: aws, policy , or iam.


## IAM Role Naming Standards
IAM role names should not contain forbidden words. This rule denies IAM roles that does not follow role naming standards by validating and ensuring the role name does not contain any of the following words: aws, role , or federated.

## IAM Role Types
A role should not trust both another account, a service, and an IDP. This rule denies IAM roles that have multiple role types in the trust policy by validating and ensuring the role only has one role type.

## IAM Service Star Policy
IAM policies should adhere to the principle of least privilege. This rule denies any type of IAM policy that uses the wildcard attribute with service actions by validating and ensuring the wildcard is not used and actions are listed.

## IAM Resource Star Policy
IAM policies should adhere to the principle of least privilege. This rule denies any type of IAM policy that permits powerful actions and uses a wildcard attribute for resource by validating and ensuring powerful actions are scoped to a specific resource

## IAM User Creation
IAM Users are denied upon creation because the local credentials are not tied back to a person/service account, thus reducing the visibility and tracebility of that specific IAM User.

## IAM Policy Document Principal Star
As a best practice, services should never be configured with permissions granted to Everyone. This rule denies IAM Policy Document policies that extend permissions to be made publicly accessible by validating and ensuring the policy does not grant permissions when a principal attribute is set to a wildcard such as  **\*** with no limiting condition applied.

