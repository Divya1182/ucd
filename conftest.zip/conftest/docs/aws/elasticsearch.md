<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: Elasticsearch/OpenSearch Conftest Policies -->
<!-- Layout: plain -->

 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Elasticsearch/OpenSearch conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_elasticsearch_domain resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Elasticsearch/OpenSearch visit [OpenSearch](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=549563435

<!-- Add link to Service Policy page -->

View all Elasticsearch/OpenSearch policies on [OpenSearch Policy](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=549572902).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                     | Rule Description                                      | Conftest Rule                                                                                                                        | Terraform Cases                                                                                                                                  | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| -------------------------- | ----------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------ | --------- | ------------------------------------------------------------- |
| **Elasticsearch with VPC** | Deny Elasticsearch if it is not configured with a VPC | [elasticsearch_vpc](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/elasticsearch/elasticsearch_vpc.rego) | [elasticsearch_vpc.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/elasticsearch/elasticsearch_vpc.tf) | deny      | v0.9                                                          |

<!-- More description of each rule, functionality  -->

## Elasticsearch/OpenSearch with VPC

Amazon Elasticsearch is an open-source, RESTful, distributed search and analytics engine built on Apache Lucene. This policy denies any elasticsearch resource that is not used with a VPC, setting up an elasticsearch publicly will be denied. This is done under the Network configuration section, choose VPC acess and not Public access.
