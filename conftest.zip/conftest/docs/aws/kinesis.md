<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: Kinesis Conftest Policies -->
<!-- Layout: plain -->

 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Kinesis conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_kinesis_stream resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Kinesis visit [the service page](https://confluence.sys.cigna.com/display/CLOUD/Kinesis)

<!-- Add link to Service Policy page -->

View all Kinesis policies on [Kinesis Policy](https://confluence.sys.cigna.com/display/CLOUD/Kinesis+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                              | Conftest Rule                                                                                                                 | Terraform Cases                                                                                                                           | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Kinesis Stream Encrypted** | Deny kinesis streams that are not encrypted at rest         | [kinesis_encrypted](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/kinesis/kinesis_encrypted.rego) | [kinesis_encrypted.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/kinesis/kinesis_encrypted.tf) | deny      | v0.19                                                         |

<!-- More description of each rule, functionality  -->

## Kinesis Encrypted

Kinesis streams store data at rest and therefore should be encrypted. If the `encryption_type` and `kms_key_id` attributes do  is not set the rule will fail.
