<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: API Gateway Conftest Policies -->
<!-- Layout: plain -->

 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following API Gateway conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_api_gateway_stage resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about API Gateway visit [API Gateway](https://confluence.sys.cigna.com/display/CLOUD/API+Gateway)

<!-- Add link to Service Policy page -->
View all API Gateway policies on [API Gateway Policy](https://confluence.sys.cigna.com/display/CLOUD/API+Gateway+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**API Gateway Logging**|Deny API Gateway Stages that do not have access logging configured | [api_gw_logging_enabled](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/api-gw/api_gw_logging_enabled.rego)|[api_gw_logging_enabled.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/api-gw/api_gw_logging_enabled.tf)|deny|v0.4|
|**API Gateway Custom Domain**|Deny API Gateway APIs that do not have a custom domain | [api_gw_custom_domain](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/api-gw/api_gw_custom_domain.rego)|[api_gw_custom_domain.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/api-gw/api_gw_custom_domain.tf)|deny|v0.15|
<!-- More description of each rule, functionality  -->
## API Gateway Logging
API Gateway has the ability to implement access logging integrated with CloudWatch Logs. This rule denies API Gateway Stages that do not have access logging configured.

## API Gateway Custom Domain
API Gateway has the ability to have a custom domain. This helps with operational resiliency and is a requirement for specifying the TLS version. This rule ensures a domain is mapped to any rest api resource.