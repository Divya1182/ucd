<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: ACM Conftest Policies -->
<!-- Layout: plain -->

<!-- Macro: :wip:
     Template: ac:status
     Title: WORK IN PROGRESS
     Color: Red -->

 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following AWS Certificate Manager(ACM) conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_acm_certificate resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about ACM visit [AWS Certificate Manager (ACM)](https://confluence.sys.cigna.com/display/CLOUD/Certificate+Manager)

<!-- Add link to Service Policy page -->

Service Policy Page WIP

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy             | Rule Description                                     | Conftest Rule                                                                                                            | Terraform Cases                                                                                                                                                        | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ------------------ | ---------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **ACM Validation** | Deny all ACM certificates if validation is by email. | [acm_dns_validation](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/acm/acm_dns_validation.rego) | [acm_dns_validation_fail.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/acm/acm_dns_validation_fail.tf) | deny      | v0.9                                                          |

<!-- More description of each rule, functionality  -->

## ACM Validation

[AWS Certificate Manager (ACM)](https://aws.amazon.com/certificate-manager/) is a service that lets you easily provision, manage, and deploy public and private Secure Sockets Layer/Transport Layer Security (SSL/TLS) certificates for use with AWS services and your internal connected resources. This policy is designed to ensure that ACM certificates are validated with DNS not email.

