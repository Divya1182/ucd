<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: EC2 Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following EC2 conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_instance resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about EC2 visit [The Service Page](https://confluence.sys.cigna.com/display/CLOUD/EC2)

<!-- Add link to Service Policy page -->
View all EC2 policies on [EC2 Policy](https://confluence.sys.cigna.com/display/CLOUD/EC2+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**EC2 Instance Role**|Deny all EC2 instances that do not have a role via an instance profile | [ec2_instance_role](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/ec2/ec2_instance_role.rego)|[ec2_instance_role.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/ec2/ec2_instance_role.tf)|deny|v0.8|

<!-- More description of each rule, functionality  -->
## EC2 Instance Role
Instance roles are required for cloudwatch logging to function. Therefore there is a risk of logging data loss if not enabled.
Additionally this could mean long lived aws credentials are used instead.



<!-- Add Bucket Tagging Policy reference if service is included in tagging validation  -->
## EC2 Instance Tagging
Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

