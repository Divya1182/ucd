<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: Load Balancer: ALB, ELB, NLB Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following Load Balancer conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_lb and aws_elb resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about Load Balancers visit [The Service Page](https://confluence.sys.cigna.com/display/CLOUD/Load+Balancer%3A+ALB%2C+ELB%2C+NLB)

<!-- Add link to Service Policy page -->
View all Load Balancer policies on [Load Balancer Policy](https://confluence.sys.cigna.com/display/CLOUD/ELB+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**Application Load Balancer Access Logs**|Deny ALBs that do not have access logging configured | [alb_access_logs](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/load-balancer/alb_access_logs.rego)|[alb_access_logs.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/load-balancer/alb_access_logs.tf)|deny|v0.10|
|**Application Load Balancer SSL Protocol**|Deny ALBs that do not have encryption configured with an AWS recommended SSL Policy| [alb_ssl_protocol](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/load-balancer/alb_ssl_protocol.rego)|[alb_ssl_protocol.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/load-balancer/alb_ssl_protocol.tf)|deny|v0.10|
|**Elastic (Classic) Load Balancer SSL Protocol**|Deny ELBs that do not have encryption configured with an AWS recommended SSL Policy| [elb_classic_ssl_protocol](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/load-balancer/elb_classic_ssl_protocol.rego)|[elb_classic_ssl_protocol.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/load-balancer/elb_classic_ssl_protocol.tf)|deny|v0.8|
|**Elastic (Classic) Load Balancer TLS Enabled**|Deny ELBs that do not have encryption configured with a valid SSL Certificate ID on the ELB Listener| [elb_classic_tls_enabled](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/load-balancer/elb_classic_tls_enabled.rego)|[elb_classic_tls_enabled.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/load-balancer/elb_classic_tls_enabled.tf)|deny|v0.8|

<!-- More description of each rule, functionality  -->
## Application Load Balancer Access Logs
ALBs have the capability to track user access through Access Logging. This is identified by the ``access_logs`` attribute being set.
When not set the rule will fail.

## Application Load Balancer SSL Protocol
ALBs can enforce that traffic flowing through the load balancer is encrypted. This is identified by:
``ssl_policy`` attribute being set to an AWS recommended SSL Policy, ``protocol`` attribute being set to HTTPs and ``certificate_arn`` attribute being populated with a valid ssl certificate arn.
When these are not set, the rule will fail.

## Elastic (Classic) Load Balancer SSL Protocol
Classic ELBs are required to enforce encryption with a propper TLS protocol configuration. This is identified by the ``policy_attribute`` set values ``name`` attribute being populated and ``value``  attribute being set to true.
When not set the rule will fail.

## Elastic (Classic) Load Balancer TLS Enabled
Classic ELB Listeners are required to enforce encryption with a propper SSL Certificate. This is identified by the ``lb_protocol`` being set to HTTPS and the ``ssl_certificate_id`` attribute being set with a valid SSL Certificate.
When not set the rule will fail.

## Load-Balancer Tagging
Tagging Policy will also validate all minimum required tags. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

