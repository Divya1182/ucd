<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: MediaStore Conftest Policies -->
<!-- Layout: plain -->


 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following MediaStore conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_media_store_container_policy resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).


<!-- Add link to Service Policy page -->
View all MediaStore policies on [MediaStore Policy](https://confluence.sys.cigna.com/display/CLOUD/MediaStore+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**MediaStore Container Policy Restricted Principal**| Deny MediaStore Container policies that have wildcard principals with no limiting conditions defined. | [mediastore_restricted_principal.rego](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/mediastore/mediastore_restricted_principal.rego)|[mediastore_restricted_principal.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/mediastore/mediastore_restricted_principal.tf)|deny|v0.33|

<!-- More description of each rule, functionality  -->
## MediaStore Principal Restriction
Any publicly accessible MediaStore Container policies available in an AWS account are subject to unauthorized users. Restrict the container policy to only select principals or limiting conditions to avoid this issue.
