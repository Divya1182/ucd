<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: EBS Conftest Policies-->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following EBS (Elastic Block Store) conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate ``aws_ebs_volume`` resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about EBS visit [The Service Page](https://confluence.sys.cigna.com/display/CLOUD/EBS)

<!-- Add link to Service Policy page -->
View all EBS policies on [EBS Policy](https://confluence.sys.cigna.com/display/CLOUD/EBS+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**EBS Volume Encrypted**|Deny EBS Volumes that do not have encryption enabled | [ebs_volume_encrypted](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/ebs/ebs_volume_encrypted.rego)|[ebs_volume_encrypted.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/ebs/ebs_volume_encrypted.tf)|deny|v0.1|

<!-- More description of each rule, functionality  -->
## EBS Volume Encryption
Elastic Block Stores can be set to encrypt everything that is stored inside the volume. This is identified by the ``encrypted`` attribute being set to true.
When not set to True the rule will fail.

<!-- Add Bucket Tagging Policy reference if service is included in tagging validation  -->
## EBS Volume Tagging
Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

