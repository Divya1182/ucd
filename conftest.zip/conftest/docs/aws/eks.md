<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: EKS Conftest Policies -->
<!-- Layout: plain -->

     
<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following EKS conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_eks_cluster resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about EKS visit [EKS](https://confluence.sys.cigna.com/display/CLOUD/EKS)

<!-- Add link to Service Policy page -->
View all EKS policies on [EKS Policy](https://confluence.sys.cigna.com/display/CLOUD/EKS+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**EKS Control Plane Logging**|Deny eks clusters that do not have eks control plane logging enabled.| [eks_controlplane_logging](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/eks/eks_controlplane_logging.rego)|[eks_controlplane_logging.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/eks/eks_controlplane_logging.tf)|deny|v0.11|
|**EKS Public Endpoint**|Deny eks clusters contain a VPC config allowing public access.| [eks_public_endpoint](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/eks/eks_public_endpoint.rego)|[eks_public_endpoint.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/eks/eks_public_endpoint.tf)|deny|v0.9|
|**EKS Version**|Deny eks versions that are no longer supported by AWS.| [eks_version](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/eks/eks_version.rego)|[eks_version.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/eks/eks_version.tf)|deny|v0.47|
|**EKS CMK Encryption**|Deny eks clusters that do not leverage a customer managed KMS key (CMK) for secret encryption.| [eks_cmk_encryption](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/eks/eks_cmk_encryption.rego)|[eks_version.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/eks/eks_cmk_encryption.tf)|deny|v0.46|

<!-- More description of each rule, functionality  -->
## EKS Control Plane Logging
When the EKS Control Plane Logging feature is enabled, Amazon EKS sends audit and diagnostic logs directly to AWS CloudWatch Logs. These logs can help you to secure and efficiently run your EKS clusters. This rule denies eks clusters that does not have eks control plane logging enabled by validating and ensuring that cluster log types are enabled.

## EKS Public Endpoint
EKS Endpoints are made public by default. By specifying it be private you can enable private access to the Kubernetes API server so that all communication between your nodes and the API server stays within your VPC.

## EKS Version
Kubernetes Versions become deprecated on EKS about every 5 months. This policy is ensuring the version is at least 1.19 to prevent deprecated versions from being used.

Please see this page for more information on supported EKS kubernetes versions: [https://docs.aws.amazon.com/eks/latest/userguide/kubernetes-versions.html#kubernetes-release-calendar](https://docs.aws.amazon.com/eks/latest/userguide/kubernetes-versions.html#kubernetes-release-calendar)

## EKS CMK Encryption
EKS clusters can contain Kubernetes Secret objects.  These contain private data such as keys, tokens, and passwords used by pods.  Users must provide a customer managed KMS key when creating the cluster to ensure that it adheres to Cigna best practices for KMS.


<!-- Add Tagging Policy reference if service is included in tagging validation  -->
## EKS Tagging
Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

