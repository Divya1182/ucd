<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: SQS Conftest Policies -->
<!-- Layout: plain -->


 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following SQS conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_sqs_queue and aws_sqs_queue_policy resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about SQS visit [Simple Queue Service (SQS)](https://confluence.sys.cigna.com/pages/viewpage.action?spaceKey=CLOUD&title=SQS)

<!-- Add link to Service Policy page -->
View all SQS policies on [SQS Policy](https://confluence.sys.cigna.com/display/CLOUD/Simple+Queue+Service+%28SQS%29+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**SQS Restricted Principal**| Deny SQS policies that have wildcard principals with no limiting conditions defined. | [sqs_restricted_principal](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/sqs/sqs_restricted_principal.rego)|[sqs_restricted_principal.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/sqs/sqs_restricted_principal.tf)|deny|v0.11|
|**SQS Encryption**| Deny SQS queues that do not have server side encryption. | [sqs_server_side_encryption](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/sqs/sqs_server_side_encryption.rego)|[sqs_server_side_encryption.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/sqs/sqs_server_side_encryption.tf)|deny|v0.6|

<!-- More description of each rule, functionality  -->
## SQS Principal Restriction
Any publicly accessible SQS queues available in an AWS account are subject to unauthorized users. Restrict the SQS queue policy to only select principals or limiting conditions to avoid this issue.

## SQS Encryption
Ensure that Amazon Simple Queue Service (SQS) queues are protecting the contents of their messages using Server-Side Encryption (SSE). The SQS service uses an AWS KMS Customer Master Key (CMK) to generate data keys required for the encryption/decryption process of SQS messages.

<!-- Add Bucket Tagging Policy reference if service is included in tagging validation  -->
## SQS Tagging
Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

