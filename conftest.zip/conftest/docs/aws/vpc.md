<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: VPC Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following VPC conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_vpc resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about VPC visit [Virtual Private Cloud (VPC)](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=197680330)

<!-- Add link to Service Policy page -->
View all VPC policies on [VPC Policy](https://confluence.sys.cigna.com/display/CLOUD/VPC+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy                                  | Rule Description                                               | Conftest Rule                                                                                                                    | Terraform Cases                                                                                                                                          | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| --------------------------------------- | -------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **VPC Flow Log**                        | Deny all VPCs that do not have flow logs enabled.              | [vpc_flow_log](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/vpc/vpc_flow_log.rego)                     | [vpc_flow_log.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/vpc/vpc_flow_log.tf)                                 | deny      | v0.1                                                          |
| **VPC Internet Gateway Creation Block** | Deny all Internet Gateways.                                    | [vpc_igw_creation_block](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/vpc/vpc_igw_creation_block.rego) | [vpc_igw_creation_block.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/vpc/vpc_igw_creation_block.tf) | deny      | v0.8                                                          |
| **Golden VPC Version**                  | Deny all golden vpc modules that are older than version 1.6.0. | [golden_vpc](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/modules/golden_vpc.rego)                     | [golden_vpc.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/modules/golden_vpc.tf)                     | deny      | v0.10                                                          |
| **VPC Peering Connection**              | Deny all VPC peering connections.                              | [vpc_peering_connection](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/vpc/vpc_peering_connection.rego) | [vpc_peering_connection.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/vpc/vpc_peering_connection.tf) | deny      | v0.10                                                         |
<!-- More description of each rule, functionality  -->
## VPC Flow Log
VPC Flow Logs capture information about the IP traffic going to and from network interfaces in the associated VPC. By logging all of the traffic from a given interface or an entire subnet, root cause analysis can reveal critical gaps in security where malicious traffic is moving around your network. By default, vpc flow logs are disabled.

## VPC Internet Gateway Creation Block
An internet gateway is a horizontally scaled, redundant, and highly available VPC component that allows communication between the associated VPC and the internet. To avoid opening VPCs to the internet, all internet gateways are denied deployment.

## Golden VPC Version
The Cloud COE team has developed a golden vpc module to deploy a secure Cignatized VPC. The CCOE team is actively updating the terraform module to fix security vulnerabilities, bugs and performance issues, so it is recommended to use a version of 1.6.0 or newer. 

## VPC Peering Connection
A VPC peering connection is a networking connection between two VPCs that enables you to route traffic between them using private IPv4 addresses or IPv6 addresses. To avoid security risks, all vpc peering connections are denied deployment.

<!-- Add Bucket Tagging Policy reference if service is included in tagging validation  -->
## VPC Tagging
Tagging Policy will also validate all minimum required tags are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

