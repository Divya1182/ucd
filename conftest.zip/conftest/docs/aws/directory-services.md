<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: Directory Services Conftest Policies -->
<!-- Layout: plain -->

<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following Directory Services conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_directory_service_directory resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about Directory Services visit [Directory Services](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=478720002)

<!-- Add link to Service Policy page -->
View all Directory Services policies on [Directory Services Policy](https://confluence.sys.cigna.com/display/CLOUD/Directory+Services+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**Directory Services Supported Types**|This rule denies Directory Services resources from being created that are any of the unsupported DS types that are not "MicrosoftAD".| [directory_services_ms_ad_only](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/directory-services/directory_services_ms_ad_only.rego)|[dynamodb_encrypted.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/directory-services/directory_services_ms_ad_only.tf)|deny|v0.35|

<!-- More description of each rule, functionality  -->
## Directory Services Supported Types
The directory service AWS service is currently available by exception-only by the Cloud COE.  Due to this, in order to encourage use of only supported types of directory services all unsupported types of DS are restricted.  This means that "SimpleAD" and "ADConnector" are both denied DS types.  In order to gain an exception for another type please reach out to the Cloud COE.

<!-- Add Tagging Policy reference if service is included in tagging validation  -->
## Directory Services Tagging
Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).
