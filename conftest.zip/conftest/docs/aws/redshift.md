<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: Redshift Conftest Policies -->
<!-- Layout: plain -->

 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Redshift conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate `aws_redshift` resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Redshift visit [the service page](https://confluence.sys.cigna.com/display/CLOUD/Redshift)

<!-- Add link to Service Policy page -->

View all Redshift policies on [Redshift Policy](https://confluence.sys.cigna.com/display/CLOUD/Redshift+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                              | Conftest Rule                                                                                                                 | Terraform Cases                                                                                                                           | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Redshift Encrypted** | Deny redshift clusters that are not encrypted at rest         | [redshift_encrypted](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/redshift/redshift_encrypted.rego) | [redshift_encrypted.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/redshift/redshift_encrypted.tf) | deny      | v0.5                                                          |
| **Redshift Logging**   | Deny redshift clusters that do not have audit logging enabled | [redshift_logging](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/redshift/redshift_logging.rego)     | [redshift_logging.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/redshift/redshift_logging.tf)     | deny      | v0.8                                                          |
| **Redshift TLS Connections**   | Deny Redshift parameter groups that do not ensure tls connections. | [redshift_tls](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/redshift/redshift_tls.rego)     | [redshift_tls.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/redshift/redshift_tls.tf)     | deny      | v0.11  
| **Redshift Publicly Accessible**   | Deny Redshift clusters that are made public. | [redshift_publicly_accessible](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/redshift/redshift_redshift_publicly_accessible.rego)     | [redshift_publicly_accessible.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/redshift/redshift_publicly_accessible.tf)     | deny      | v0.28                                                         |

<!-- More description of each rule, functionality  -->

## Redshift Encrypted

Redshift clusters store data at rest and therefore should be encrypted. If the `encrypted` attribute is not set the rule will fail.

## Redshift Logging

Redshift cluster have additional audit logging about the activity on the cluster beyond what cloudtrail provides. If the `logging` attribute is not set the rule will fail.

## Redshift TLS Connections
Redshift clusters do not encrypt data in transit by default. This rule identifies Redshift databases in which data connection to and from is occurring on an insecure channel. TLS connections ensures the security of the data in transit.

## Redshift Publicly Available
Redshift Clusters can be made publicly accessible by setting the publicly_accessible flag to 'true'. Setting this to false will help prevent unauthorized access to your clusters.

<!-- Add Bucket Tagging Policy reference if service is included in tagging validation  -->

## Redshift Cluster Tagging

Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

