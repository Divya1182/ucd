<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: SNS Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following SNS conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_sns_topic and aws_sns_topic_policy resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about SNS visit [Simple Notification Service (SNS)](https://confluence.sys.cigna.com/display/CLOUD/SNS)

<!-- Add link to Service Policy page -->
View all SNS policies on [SNS Policy](https://confluence.sys.cigna.com/display/CLOUD/SNS+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**SNS Encryption**|Deny SNS topics that are not server-side encrypted.| [sns_encryption](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/sns/sns_encryption.rego)|[sns_encryption.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/sns/sns_encryption.tf)|deny|v0.8|
|**SNS Restricted Principal**|Deny SNS topic policies that extend permissions to be made publicly accessible| [sns_restricted_principal](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/sns/sns_restricted_principal.rego)|[sns_restricted_principal.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/sns/sns_restricted_principal.tf)|deny|v0.8|

<!-- More description of each rule, functionality  -->
## SNS Encryption
Sns topics should be encrypted for additional protection of sensitive data delivered as messages to subscribers. This rule denies SNS topics that are not encrypted by validating server side encryption is enabled.

## SNS Restricted Principal
As a best practice, topics should never be configured with permissions granted to Everyone. This rule denies SNS topic policies that extend permissions to be made publicly accessible by validating and ensuring the policy does not grant permissions when a principal attribute is set to a wildcard such as  **\***.

<!-- Add Tagging Policy reference if service is included in tagging validation  -->
## SNS Tagging
Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

