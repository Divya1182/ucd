<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: DynamoDB Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following DynamoDB conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_dynamodb_table resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about DynamoDB visit [DynamoDB](https://confluence.sys.cigna.com/display/CLOUD/DynamoDB)

<!-- Add link to Service Policy page -->
View all DynamoDB policies on [DynamoDB Policy](https://confluence.sys.cigna.com/display/CLOUD/DynamoDB+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**Dynamodb Encryption**|Deny dynamodb tables that are encrypted using AWS Owned CMK.| [dynamodb_encrypted](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/dynamodb/dynamodb_encrypted.rego)|[dynamodb_encrypted.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/dynamodb/dynamodb_encrypted.tf)|deny|v0.11|

<!-- More description of each rule, functionality  -->
## Dynamodb Encryption
Organizational policies, industry or government regulations, and internal compliance requirements often require the use of Server-Side Encryption (SSE) using AWS-managed KMS Customer Master Keys (CMKs) to enhance the data security of your Amazon DynamoDB-based applications. This rule denies dynamodb tables that are encrypted using AWS Owned CMK by validating and ensuring that dynamodb is encrypted using AWS Managed CMK.

<!-- Add Tagging Policy reference if service is included in tagging validation  -->
## DynamoDB Tagging
Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).

