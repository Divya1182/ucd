<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: Security Group Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following Security Groups rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_security_group resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about Security Groups visit [The Service Page](https://confluence.sys.cigna.com/display/CLOUD/Security+Groups)

<!-- Add link to Service Policy page -->
View all Security Group policies on [Security Group Policies](https://confluence.sys.cigna.com/display/CLOUD/Security+Groups+Remediation+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**Security Groups Ingress Anywhere**|Deny all VPC Security Groups that allow unrestricted internet ingress from any ports other than 80 and 443 | [security_group_ingress_anywhere](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/security-group/security_group_ingress_anywhere.rego)|[security_group_ingress_anywhere.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/security-group/security_group_ingress_anywhere.tf)|deny|v0.1|
|**Security Groups Ingress Port Range**|Deny all VPC Security Groups that allow unrestricted internet ingress from all ports | [security_group_ingress_port_range](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/security-group/security_group_ingress_port_range.rego)|[security_group_ingress_port_range.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/security-group/security_group_ingress_port_range.tf)|deny|v0.10|

<!-- More description of each rule, functionality  -->
## Security Groups Ingress Anywhere
A Security Group acts as a virtual firewall for your instance to control inbound and outbound traffic. Overly permissive Security Groups can allow for unrestricted access from the internet to the VPC it is attached to. This rule denies any Security Group that allows 0.0.0.0/0 CIDR block on any port other than 80 and 443. 



<!-- Add Bucket Tagging Policy reference if service is included in tagging validation  -->
## Security Groups Ingress Port Range
This rule acts as almost the same above. The difference being in Terraform there is a way to configure a Security Group with a "protocol" of "-1" which acts semantically as an "all". With ports set to zero this would allow ingress across all ports without defining a port range or specific port number.

