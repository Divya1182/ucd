<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: Neptune Conftest Policies -->
<!-- Layout: plain -->

 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Neptune conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_neptune_cluster resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Neptune visit [Neptune]https://confluence.sys.cigna.com/display/CLOUD/Neptune)

<!-- Add link to Service Policy page -->

View all Neptune policies on [Neptune Policy](https://confluence.sys.cigna.com/display/CLOUD/Neptune+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                     | Rule Description                                      | Conftest Rule                                                                                                                        | Terraform Cases                                                                                                                                  | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| -------------------------- | ----------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------ | --------- | ------------------------------------------------------------- |
| **Neptune Publicly Accessible** | Deny Neptune Cluster Instances if the 'publicly_accessible' flag is set to true | [neptune_publicly_accessible](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/neptune/neptune_publicly_accessible.rego) | [neptune_publicly_accessible.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/neptune/neptune_publicly_accessible.tf) | deny      | v0.30                                                          |

<!-- More description of each rule, functionality  -->

## Neptune Publicly Accessible

Amazon Neptune allows for Neptune Cluster Instances to be made publicly accessible by setting the 'publicly_accessible' flag to true. Setting this to false will help prevent unauthorized access to your Neptune Cluster Instance.