<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: SES Conftest Policies -->
<!-- Layout: plain -->


 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following SES conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_ses_identity_policy resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about SES visit [Simple Email Service (SES)](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=239335313)

<!-- Add link to Service Policy page -->
View all SES policies on [SES Policy](https://confluence.sys.cigna.com/display/CLOUD/Simple+Email+Service+%28SES%29+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**SES Restricted Principal**| Deny SES Identity policies that have wildcard principals with no limiting conditions defined. | [ses_restricted_principal](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/ses/ses_restricted_principal.rego)|[ses_restricted_principal.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/ses/ses_restricted_principal.tf)|deny|v0.32|

<!-- More description of each rule, functionality  -->
## SES Principal Restriction
Any publicly accessible SES Identities available in an AWS account are subject to unauthorized users. Restrict the SES Identity policy to only select principals or limiting conditions to avoid this issue.
