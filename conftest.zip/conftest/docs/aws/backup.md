<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: Backup Conftest Policies -->
<!-- Layout: plain -->

 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following AWS Backup conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_backup_policy resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Backup visit [AWS Backup](https://confluence.sys.cigna.com/display/CLOUD/AWS+Backup)

<!-- Add link to Service Policy page -->
View all AWS Backup policies on [AWS Backup](https://confluence.sys.cigna.com/display/CLOUD/Backup).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**Backup Vault Policy Restricted Principal**|Deny Backup Vault Policies that contain Principal * with no limiting condition | [backup_vault_policy_restricted_principal](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/backup/backup_vault_policy_restricted_principal.rego)|[backup_vault_policy_restricted_principal.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/backup/backup_vault_policy_restricted_principal.tf)|deny|v0.32|

<!-- More description of each rule, functionality  -->
## Backup Vault Policy Restricted Principal
Any publicly accessible Backup Vault Policies available in an AWS account are subject to unauthorized users taking actions upon backups within the Vault. Restrict the Backup Vault policy to only select principals or limiting conditions to avoid this issue.
