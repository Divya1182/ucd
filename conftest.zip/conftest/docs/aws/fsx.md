<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: FSx Conftest Policies -->
<!-- Layout: plain -->

<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following FSx Windows File Server conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_fsx_windows_file_system resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about FSx visit [FSx Windows File Server](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=490987196s)

<!-- Add link to Service Policy page -->
View all FSx policies on [FSx Policy](https://confluence.sys.cigna.com/display/CLOUD/FSx+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**FSx Logging Configured**|This rule denies FSx resources from being created that do not leverage a log group that captures all FSx access requests.| [fsx_logging_configured](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/fsx/fsx_logging_configured.rego)|[fsx_logging_configured.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/fsx/fsx_logging_configured.tf)|deny|v0.37|
|**FSx Managed AD Denied**|This rule denies FSx resources from being created that do not leverage AWS Managed Microsoft AD in their file shares.| [fsx_managed_ad_denied](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/fsx/fsx_managed_ad_denied.rego)|[fsx_managed_ad_denied.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/fsx/fsx_managed_ad_denied.tf)|deny|v0.37|
|**FSx Backup Enforced**|This rule denies FSx resources from being created that do not leverage either built-in FSx backupr or AWS Backups plans on FSx file servers| [fsx_backup_enforced](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/fsx/fsx_backup_enforced.rego)|[fsx_backup_enforced.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/fsx/fsx_backup_enforced.tf)|deny|v0.37|

<!-- More description of each rule, functionality  -->
## FSx Logging Configured
The FSx AWS service is a service that allows files to be shared.  Resources like Windows EC2 instances that are domain joined can quickly gain access to these shared files.  Further permissions can be applied via share permissions or NTFS permissions on these file share directories.  All access requests on these file shares must be logged to a log group in order to provide traceability on security.  All FSx Windows file servers that do not configure logging will be denied.

## FSx Managed AD Denied
In order to create an FSx Windows file server, an Active Directory must be utilized and have connectivity to FSx.  The only possible AWS cloud solution to an Active Directory connected is AWS managed MS AD.  Therefore, self-managed Active Directory connections are not permitted.  This policy works to enforce this.

## FSx Backup Enforced
There are many backup options when it comes to FSx Windows file servers.  There are built-in daily backups which can be stored for a specified number of days.  Alternatively, this could be disabled and AWS backup can be leveraged with FSx.  This policy works to ensure that at least one of these backup options is enabled.

<!-- Add Tagging Policy reference if service is included in tagging validation  -->
## FSx Tagging
Tagging Policy will also validate all minimum required tags and tags for data at rest are present. For more about Resource [Tagging Conftest Policies](https://confluence.sys.cigna.com/display/CLOUD/Tagging+Conftest+Policies).
