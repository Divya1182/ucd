<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: KMS Conftest Policies -->
<!-- Layout: plain -->

     
 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->
The following KMS conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_kms_key resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->
For more information about KMS visit [The Service Page](https://confluence.sys.cigna.com/display/CLOUD/KMS)

<!-- Add link to Service Policy page -->
View all KMS policies on [KMS Policy](https://confluence.sys.cigna.com/display/CLOUD/KMS+Policy).

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->
| Policy | Rule Description | Conftest Rule | Terraform Cases | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
|---|---|---|---|---|---|
|**KMS Key Rotation**|Deny all KMS Key creation that does not have Key Rotation enabled | [kms_rotate](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/kms/kms_rotate.rego)|[kms_rotate.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/kms/kms_rotate.tf)|deny|v0.1|
|**KMS Publicly Accessible**|Deny all KMS Key creation that has an policy attached setting Principal to a wildcard (*) | [kms_principal_star](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/kms/kms_principal_star.rego)|[kms_principal_star.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/kms/kms_principal_star.tf)|deny|v0.30|

<!-- More description of each rule, functionality  -->
## KMS Key Rotation
Cryptographic best practices discourage extensive reuse of encryption keys. When you enable automatic key rotation for a customer managed CMK, AWS KMS generates new cryptographic material for the CMK every year.

## KMS Publicly Accessible
KMS Keys can be made publicly accessible through a resource policy. KMS Key resource policies should be scoped to a specific principal or have a limiting condition present.

