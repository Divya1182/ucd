<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: AWS Conftest Policies -->
<!-- Title: Elasticache Conftest Policies -->
<!-- Layout: plain -->


 <!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following ElastiCache conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate aws_ElastiCache_replication_group resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about ElastiCache visit [ElastiCache](https://confluence.sys.cigna.com/display/CLOUD/ElastiCache)

<!-- Add link to Service Policy page -->

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy          | Rule Description                                                      | Conftest Rule                                                                                                                                 | Terraform Cases                                                                                                                               | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| --------------- | --------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **ElastiCache** | Deny if ElastiCache encryption is not enabled at rest and in transit. | [ElastiCache_encryption.rego](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/aws/elasticache/elasticache_encryption.rego) | [ElastiCache_encryption.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/aws/elasticache/elasticache_encryption.tf) | deny      | v0.8                                                          |

<!-- More description of each rule, functionality  -->

[ElastiCache Encryption](https://aws.amazon.com/elasticache/) allows you to seamlessly set up, run, and scale popular open-Source compatible in-memory data stores in the cloud. This policy is designed to ensure that ElastiCache resources are encrypted at rest and in transit.

