<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Function App Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Functionapp conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_function_app resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Function Apps at Cigna visit [Azure Functionapp Service Page](https://confluence.sys.cigna.com/display/CLOUD/Azure+Functions).

<!-- Add link to Service Policy page -->

[Azure Functionapp Service Policy Page](https://confluence.sys.cigna.com/display/CLOUD/Azure+Functions+Policy)

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Functionapp TLS Requirement** | Deny functionapp resources that do not leverage at least TLS version 1.2. | [functionapp_tls_requirement](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/functionapp/functionapp_tls_requirement.rego) | [functionapp_tls_requirement.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/functionapp/functionapp_tls_requirement.tf) | deny      | v0.40                                                          |
| **Functionapp HTTPS Requirement** | Deny functionapp resources that do not require HTTPS function endpoint connections. | [functionapp_https_requirement](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/functionapp/functionapp_https_requirement.rego) | [functionapp_https_requirement.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/functionapp/functionapp_https_requirement.tf) | deny      | v0.40                                                          |
<!-- More description of each rule, functionality  -->

## Functionapp TLS Requirement
This rule denies functionapp resources from being created that do not utilize the required minimum TLS version 1.2

## Functionapp HTTPS Requirement
This rule denies functionapp resources from being created that do not require client connections to function endpoints to leverage HTTPS
