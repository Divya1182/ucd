<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Front Door Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Front Door conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_storage_account resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Front Doors visit Front Doors.

<!-- Add link to Service Policy page -->

Service Policy Page WIP

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Front Door WAF Enabled** | Azure Front Door should have an attached web application firewall policy. | [front_door_waf_enabled](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/storage-account/front_door_waf_enabled.rego) | [front_door_waf_enabled.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/storage-account/front_door_waf_enabled.tf) | deny      | v0.38                                                         |
| **Front Door HTTPS** | Azure Front Door should enable https traffic only or redirect http to https traffic. | [front_door_https](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/storage-account/front_door_https.rego) | [front_door_https.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/storage-account/front_door_https.tf) | deny      | v0.38                                                         |
<!-- More description of each rule, functionality  -->

## Front Door WAF Enabled
Azure Web Application Firewall (WAF) on Azure Front Door provides centralized protection for your web applications. WAF defends your web services against common exploits and vulnerabilities. It keeps your service highly available for your users and helps you meet compliance requirements.

## Front Door HTTPS
Azure Front Door should enable https traffic only or redirect http to https traffic. By using the HTTPS protocol on your custom domain, you ensure that your sensitive data is delivered securely via TLS/SSL encryption when it's sent across the internet. 
