<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Logic App Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Logic App conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_logic_app_standard resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Logic Apps at Cigna visit [Azure Logic App Service Page](https://confluence.sys.cigna.com/display/CLOUD/Logic+Apps).

<!-- Add link to Service Policy page -->

[Azure Logic App Service Policy Page](https://confluence.sys.cigna.com/display/CLOUD/Azure+Logic+App+Policy)

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Logic App TLS Requirement** | Deny logic app resources that do not leverage at least TLS version 1.2. | [logic_app_tls_requirement](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/logic-app/logic_app_tls_requirement.rego) | [logic_app_tls_requirement.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/logic-app/logic_app_tls_requirement.tf) | deny      | v0.40                                                          |
| **Logic App HTTPS Requirement** | Deny logic app resources that do not require HTTPS function endpoint connections. | [logic_app_https_requirement](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/logic-app/logic_app_https_requirement.rego) | [logic_app_https_requirement.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/logic-app/logic_app_https_requirement.tf) | deny      | v0.40                                                          |
<!-- More description of each rule, functionality  -->

## Logic App TLS Requirement
This rule denies Standard Logic App resources from being created that do not utilize TLS version 1.2 or higher

## Logic App HTTPS Requirement
This rule denies Standard Logic App resources from being created that do not require HTTPS protocol for app endpoint access
