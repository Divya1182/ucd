<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Databricks Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Databricks conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_databricks_workspace resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Databricks at Cigna visit [Databricks Service Page](https://confluence.sys.cigna.com/display/CLOUD/Azure+Databricks).

<!-- Add link to Service Policy page -->

[Azure Databricks Service Policy Page](https://confluence.sys.cigna.com/display/CLOUD/Azure+Databricks+Policy)

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Databricks Require CMK** | This rule denies databricks workspace resources from being created that do not require CMK to encrypt the databricks data plane for premium SKU workspaces | [databricks_require_cmk](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/databricks/databricks_require_cmk.rego) | [databricks_require_cmk.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/databricks/databricks_require_cmk.tf) | deny      | v0.43                                                          |
<!-- More description of each rule, functionality  -->

## Databricks Require CMK
This rule denies databricks workspace resources from being created that do not require CMK to encrypt the databricks data plane for premium SKU workspaces 
