<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Web App Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Web App conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_app_service resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Web Apps (App Service) at Cigna visit [Azure Web App Service Page](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=424287111&src=contextnavpagetreemode).

<!-- Add link to Service Policy page -->

[Azure Web App Service Policy Page](https://confluence.sys.cigna.com/display/CLOUD/App+Service+%28Web+App%29+Policy)

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Web App TLS Requirement** | Deny web app resources that do not leverage at least TLS version 1.2. | [web_app_tls_requirement](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/web-app/web_app_tls_requirement.rego) | [web_app_tls_requirement.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/web-app/web_app_tls_requirement.tf) | deny      | v0.40                                                          |
| **Web App HTTPS Requirement** | Deny Web App resources that do not require HTTPS endpoint connections. | [web_app_https_requirement](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/web-app/web_app_https_requirement.rego) | [web_app_https_requirement.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/web-app/web_app_https_requirement.tf) | deny      | v0.40                                                          |

<!-- More description of each rule, functionality  -->

## Web App TLS Requirement
This rule denies Web App resources from being created that do not utilize the required minimum TLS version 1.2

## Web App HTTPS Requirement
This rule denies Web App resources from being created that do not require HTTPS protocol for app endpoint access