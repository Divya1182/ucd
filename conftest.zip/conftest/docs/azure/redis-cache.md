<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Redis Cache Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Redis Cache conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_redis_cache resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Azure Redis caches at Cigna visit [Azure Redis Cache Service Page](https://confluence.sys.cigna.com/display/CLOUD/Azure+Redis+Cache)

<!-- Add link to Service Policy page -->

Azure Redis Cache Service Policy Page (Service policy page TBD...)

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Redis Cache TLS Requirement** | Deny Redis cache resources that do not leverage at least TLS version 1.2. | [redis_cache_tls_requirement](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/redis-cache/redis_cache_tls_requirement.rego) | [redis_cache_tls_requirement.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/redis-cache/redis_cache_tls_requirement.tf) | deny      | v0.43                                                          |
| **Redis Cache Restrict Public Access** | This rule denies Redis Cache resources from being created that do not configure public network access enabled to false | [redis_cache_restrict_public_access](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/redis-cache/redis_cache_restrict_public_access.rego) | [redis_cache_restrict_public_access.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/redis-cache/redis_cache_restrict_public_access.tf) | deny      | v0.43                                                          |
| **Redis Cache Require SSL Port** | This rule denies Redis Cache resources from being created that allow connections on non-SSL/TLS port 6379 | [redis_cache_require_ssl_port](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/redis-cache/redis_cache_require_ssl_port.rego) | [redis_cache_require_ssl_port.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/redis-cache/redis_cache_require_ssl_port.tf) | deny      | v0.43                                                          |

<!-- More description of each rule, functionality  -->

## Redis Cache TLS Requirement
This rule denies Redis cache resources from being created that do not utilize TLS version 1.2 or higher

## Redis Cache Restrict Public Access
This rule denies Redis Cache resources from being created that do not configure public network access enabled to false

## Redis Cache Require SSL Port
This rule denies Redis Cache resources from being created that allow connections on non-SSL/TLS port 6379