<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Storage Account Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Storage Account conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_storage_account resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Storage Accounts visit Azure Storage Account.

<!-- Add link to Service Policy page -->

Service Policy Page WIP

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Storage Account Public Access** | Creation of Public Storage Accounts is denied. | [storage_account_public](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/storage-account/storage_account_public.rego) | [storage_account_public.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/storage-account/storage_account_public.tf) | deny      | v0.12                                                          |
| **Storage Account HTTPs Traffic Only** | Storage Accounts must enable HTTPs traffic only. | [storage_account_https](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/storage-account/storage_account_https.rego) | [storage_account_https.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/storage-account/storage_account_https.tf) | deny      | v0.37                                                         |
| **Storage Account TLS 1.2** | Storage accounts require minimum TLS version of 1.2. | [storage_account_tls](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/storage-account/storage_account_tls.rego) | [storage_account_tls.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/storage-account/storage_account_tls.tf) | deny      | v0.37                                                          |

<!-- More description of each rule, functionality  -->

## Public Access to Storage Accounts
Allowing Public Access to Storage Accounts in Azure is denied.

## Storage Account HTTPs Traffic Only
Storage accounts should have enable_https_traffic_only set to true.

## *Storage Account TLS 1.2
Storage accounts should have min_tls_version set to TLS1_2.
