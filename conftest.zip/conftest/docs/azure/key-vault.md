<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Key Vault Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Key Vault conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_storage_account resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Key Vaults visit Azure Keyvault.

<!-- Add link to Service Policy page -->

Service Policy Page WIP

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Key Vault Purge Protection** | Key Vaults should have purge protection enabled. | [key_vault_purge_protection](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/storage-account/key_vault_purge_protection.rego) | [key_vault_purge_protection.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/storage-account/key_vault_purge_protection.tf) | deny      | v0.37                                                         |
| **Key Vault RBAC Authorization** | Key Vaults should have RBAC authorization enabled. | [key_vault_rbac_authorization](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/storage-account/storage_account_public.rego) | [key_vault_rbac_authorization.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/storage-account/key_vault_rbac_authorization.tf) | deny      | v0.37                                                          |
| **Key Vault Restrict Network Access** | Deny Key vault resources that allow public IP access. | [key_vault_restrict_network_access](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/key-vault/key_vault_restrict_network_access.rego) | [key_vault_rbac_authorization.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/key-vault/key_vault_restrict_network_access.tf) | deny      | v0.40                                                          |
<!-- More description of each rule, functionality  -->

## Key Vault Purge Protection
Key Vaults should have purge protection enabled. When purge protection is on, a vault or an object in the deleted state cannot be purged until the retention period has passed.

## Key Vault RBAC Authorization
Azure RBAC allows users to manage Key, Secrets, and Certificates permissions. It provides one place to manage all permissions across all key vaults.

## Key Vault Restrict Network Access
This rule denies Key Vault resources from being created that do not deny all public IPs by default in their configured network ACL.