<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Cognitive Services Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Cognitive Services conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_storage_account resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Cognitive Services visit Azure Cognitive Services.

<!-- Add link to Service Policy page -->

Service Policy Page WIP

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Cognitive Services Restrict Network Access** | Deny Cognitive Services accounts that allow public IP access. | [cognitive_services_restrict_network_access](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/cognitive-services/cognitive_services_restrict_network_access.rego) | [cognitive_services_restrict_network_access.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/cognitive-services/cognitive_services_restrict_network_access.tf) | deny      | v0.40                                                          |
| **Cognitive Services CMK Encryption** | Cognitive Services should be encrypted with a customer-managed-key. | [cognitive_services_cmk](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/cognitive-services/cognitive_services_cmk.rego) | [cognitive_services_cmk.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/cognitive-services/cognitive_services_cmk.tf) | deny      | v0.40                                                          |
| **Cognitive Services Local Authentication** | Azure Cognitive Services should have local authentication disabled. | [cognitive_services_local_authentication](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/cognitive-services/cognitive_services_local_authentication.rego) | [cognitive_services_local_authentication.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/cognitive-services/cognitive_services_local_authentication.tf) | deny      | v0.40                                                          |
| **Cognitive Services Public Access** | Azure Cognitive Services should disable public network access. | [cognitive_services_public](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/cognitive-services/cognitive_services_public.rego) | [cognitive_services_public.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/cognitive-services/cognitive_services_public.tf) | deny      | v0.40                                                          |
<!-- More description of each rule, functionality  -->


## Cognitive Services Restrict Network Access
Network access to Cognitive Services accounts should be restricted. Configure network rules so only applications from allowed networks can access the Cognitive Services account. To allow connections from specific internet or on-premises clients, access can be granted to traffic from specific Azure virtual networks or to public internet IP address ranges.

## Cognitive Services CMK Encryption
Customer-managed keys are commonly required to meet regulatory compliance standards. Customer-managed keys enable the data stored in Cognitive Services to be encrypted with an Azure Key Vault key created and owned by you. You have full control and responsibility for the key lifecycle, including rotation and management. Learn more about customer-managed keys at https://go.microsoft.com/fwlink/?linkid=2121321.

## Cognitive Services Local Authentication
Disabling local authentication methods improves security by ensuring that Cognitive Services accounts require Azure Active Directory identities exclusively for authentication. Learn more at: https://aka.ms/cs/auth.

## Cognitive Services Public Access
Disabling public network access improves security by ensuring that Cognitive Services account isn't exposed on the public internet. Creating private endpoints can limit exposure of Cognitive Services account. Learn more at: https://go.microsoft.com/fwlink/?linkid=2129800.