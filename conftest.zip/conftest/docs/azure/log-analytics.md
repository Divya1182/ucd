<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Log Analytics Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Log Analytics conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_log_analytics_workspace resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Log Analytics at Cigna visit [Azure Log Analytics Service Page](https://confluence.sys.cigna.com/display/CLOUD/Azure+Log+Analytics).

<!-- Add link to Service Policy page -->

[Azure Log Analytics Service Policy Page](https://confluence.sys.cigna.com/display/CLOUD/Azure+Log+Analytics+Policy)

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Log Analytics Disable Internet Queries** | This rule denies Log Analytics Workspace resources from being created that do not disable internet queries | [log_analytics_disable_internet_queries](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/log-analytics/log_analytics_disable_internet_queries.rego) | [log_analytics_disable_internet_queries.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/log-analytics/log_analytics_disable_internet_queries.tf) | deny      | v0.43                                                          |
<!-- More description of each rule, functionality  -->

## Log Analytics Disable Internet Queries
This rule denies Log Analytics Workspace resources from being created that do not disable internet queries