<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Database Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Azure Database conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate any azurerm_mariadb, azurerm_sql, azurerm_mssql, azurerm_mysql, and azurerm_postgresql related resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about all Azure Databases services at Cigna visit [Azure Database Service Page](https://confluence.sys.cigna.com/display/CLOUD/Azure+Database).

<!-- Add link to Service Policy page -->

[Azure Database Service Policy Page](https://confluence.sys.cigna.com/display/CLOUD/Azure+Database+Policy)

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Maria DB Require Geo Redundancy** | This rule denies MariaDB server resources from being created that do not utilize geo-redundancy. | [maria_db_require_geo_redundancy](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/database/maria_db_require_geo_redundancy.rego) | [maria_db_require_geo_redundancy.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/database/maria_db_require_geo_redundancy.tf) | deny      | v0.43                                                          |
| **MySQL Require Geo Redundancy** | This rule denies MySQL server resources from being created that do not utilize geo-redundancy. | [mysql_require_geo_redundancy](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/database/mysql_require_geo_redundancy.rego) | [mysql_require_geo_redundancy.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/database/mysql_require_geo_redundancy.tf) | deny      | v0.43                                                          |
| **PostgreSQL Require Geo Redundancy** | This rule denies PostgreSQL server resources from being created that do not utilize geo-redundancy. | [postgresql_require_geo_redundancy](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/database/postgresql_require_geo_redundancy.rego) | [postgresql_require_geo_redundancy.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/database/postgresql_require_geo_redundancy.tf) | deny      | v0.43                                                          |
| **SQL Require Geo Redundancy** | This rule denies SQL server resources from being created that do not utilize geo-redundancy with a failover group and SQL servers at different locations | [sql_require_geo_redundancy](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/database/sql_require_geo_redundancy.rego) | [sql_require_geo_redundancy.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/database/sql_require_geo_redundancy.tf) | deny      | v0.43                                                          |

<!-- More description of each rule, functionality  -->

## Maria DB Require Geo Redundancy
This rule denies MariaDB server resources from being created that do not utilize geo-redundancy

## MySQL Require Geo Redundancy
This rule denies MySql server resources from being created that do not utilize geo-redundancy

## PostgreSQL Require Geo Redundancy
This rule denies PostgreSQL server resources from being created that do not utilize geo-redundancy

## SQL Require Geo Redundancy
This rule denies SQL server resources from being created that do not utilize geo-redundancy with a failover group and SQL servers at different locations