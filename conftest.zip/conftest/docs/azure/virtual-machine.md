<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Virtual Machine Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Virtual Machine conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_windows_virtual_machine and azurerm_linux_virtual_machine resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Virtual Machines at Cigna visit [Azure Virtual Machine Service Page](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=483889530).

<!-- Add link to Service Policy page -->

[Azure Virtual Machines Service Policy Page](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=410630253)

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Virtual Machine SKU Limits** | Creation of Virtual Machines using a forbidden SKU size is denied. | [virtual_machine_sku_limits](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/virtual-machine/virtual_machine_sku_limits.rego) | [virtual_machine_sku_limits.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/virtual-machine/virtual_machine_sku_limits.tf) | deny      | v0.40                                                          |
| **Virtual Machine Auto Update** | Deny VM resources that do not leverage a patching strategy. | [virtual_machine_auto_update](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/virtual-machine/virtual_machine_auto_update.rego) | [virtual_machine_auto_update.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/virtual-machine/virtual_machine_auto_update.tf) | deny      | v0.40                                                         |
<!-- More description of each rule, functionality  -->

## Virtual Machine SKU Limits
This rule denies VM resources from being created that utilize a restricted SKU (size) for a given Windows or Linux VM

## Virtual Machine Auto Update
This rule denies VM resources from being created that do not utilize the required patching strategy for a given Windows or Linux VM.  Only a [specified list of Linux and Windows instances](https://docs.microsoft.com/en-us/azure/virtual-machines/automatic-vm-guest-patching#supported-os-images) can leverage the `AutomaticByPlatform` patch orchestration functionality.  This provides the systematic patching strategy created by MS with [availability-first updates](https://docs.microsoft.com/en-us/azure/virtual-machines/automatic-vm-guest-patching#how-does-automatic-vm-guest-patching-work).  This policy effectively denies Linux VMs from being created that do not use a Linux image listed at the page above.  However, Windows instances have an alternative patching strategy of `AutomaticByOS` for all unsupported Windows images which provides a baseline support on Patching.