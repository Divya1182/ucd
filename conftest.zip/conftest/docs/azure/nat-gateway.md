<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: NAT Gateway Conftest Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following CloudTrail conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_nat_gateway resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about NAT Gateway visit NAT Gateway.

<!-- Add link to Service Policy page -->

Service Policy Page WIP

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **NAT Gateway Creation** | Deny all NAT Gateways. | [nat_gateway](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/nat_gateway/nat_gateway.rego) | [nat_gateway.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/nat_gateway/nat_gateway.tf) | deny      | v0.11                                                          |

<!-- More description of each rule, functionality  -->

## NAT Gateway Creation
NAT Gateways are not permitted for creation in all Azure subscription.

