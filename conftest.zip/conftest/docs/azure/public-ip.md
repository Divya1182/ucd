<!-- Space: CLOUD -->
<!-- Parent: Policy as Code -->
<!-- Parent: Conftest/Open Policy Agent (OPA) -->
<!-- Parent: Azure Conftest Policies -->
<!-- Title: Public IP Conftest Policies -->
<!-- Layout: plain -->


<!-- Include: docs/_disclaimer.md -->

<!-- Add brief description of Service Policy page and which resources are being validated in policies -->

The following Public IP conftest rules leverage Open Policy Agent (OPA) to scan terraform configuration files and validate azurerm_public_ip resources. See more information about [Conftest/OPA](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=337125872).

<!-- Add link to Service page -->

For more information about Public IP visit Public IP.

<!-- Add link to Service Policy page -->

Service Policy Page WIP

## Policies

<!-- Fill out the following table including brief description for rule (1-2 sentences), link to conftest rule .rego file and link to valid/invalid .tf template -->

| Policy                 | Rule Description                                            | Conftest Rule                                                                                                                                           | Terraform Cases                                                                                                                                                     | Rule Type | [Tags](https://git.sys.cigna.com/cloud-sec-eng/conftest/tags) |
| ---------------------- | ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| **Public IP Creation** | Deny all public IPs. | [public_ip](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/terraform/azure/public-ip/public_ip.rego) | [public_ip.tf](https://git.sys.cigna.com/cloud-sec-eng/conftest/blob/master/test-files/terraform/azure/public-ip/public_ip.tf) | deny      | v0.11                                                          |

<!-- More description of each rule, functionality  -->

## Public IP Creation
Public IP are not permitted for creation in all Azure subscription.

