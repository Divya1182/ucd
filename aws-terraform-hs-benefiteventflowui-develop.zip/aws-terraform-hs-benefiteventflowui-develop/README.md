# aws-terraform-hs-benefiteventflowui
# aws-static-content-terraform-template
This is a template for using the AWS Static Content Pattern

This templates sets up the infrastructure for blue-green deployments for dev, qa, and prod. 

If your team does not need blue-green deployments, you can delete all the -candidate folders and remove the -candidate sections from the jenkinsfile.

If you need more logical environments in any of your aws accounts, you can add another folder to the envs and update your jenkinsfile accordingly. 
## Steps needed to leverage this template 
1. Click the green "Use this Template" button to get started.   
    This will prompt you to create a new repo from this template.   
    The naming convention for these types of projects is aws-terraform-appName.   
    **Note: You will need to create your repo under the Express Scripts owner in order for the CNP to build your infrastructure.**
2. Update the backend configs.   
    This file is found in each of your envs folders.   
    This controls what AWS account the infrastructure is deployed into as well as under what key your terraform state is held.   
    The key value is created by the team. It needs to be different in each logical environment.   
    Our recommendation is the env-appName so for an example dev-MyCoolApp and devcandidate-MyCoolApp. 
3. Update the tfvars files.  
    This file is also found in each of your envs folders.   
    The tfvars files are what you use to configure the static content module to work for your application.   
    Some variables can be the same between logical environments, others can not.   
    **Please ensure that environment, distribution_name, and subdomain are unique per logical environment.**
4. Update the Jenkinsfile.  
    After creating your generic ids, you will need to update the jenkinsfile with the generic id names.   
    You will also need to add your aws account numbers. 
    You will also need to update the list of approvers for each logical environment.

Please review the migration guide for more detailed instructions on each step. 

# aws-terraform-hs-benefiteventflowui 
# "Version": "1.0.0" deployed to production:first Production Deployment, with "JiraProject":"SPCFRT1","FixVersion":"SPCFRPI24.1.5.3.1.PCF.BEF"

# "Version": "1.0.1" is deployed in DEV/QA with version update for future deployments. 