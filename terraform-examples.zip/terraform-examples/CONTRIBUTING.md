# Contributing

Follow this doc if you want to add a new example Terraform snippet to this repo

## This repository contains 
- Main branch
- Feature branches

## Create a branch
- Create a branch named after the resource for which you are creating an example
- Make an initial commit

### Examples Styling
- Name the example snippet starting with the service, like `s3-create-encrypted-bucket` or `ami-pull-latest-image`. This will help quickly find the service someone is looking for.
- Add a comment section at the top of the file to give a brief description

## Open a pull request
- Open a draft pull request when you start working on a new example
- When finished, if the PR is in draft mode, take it out of draft mode

## Review process
- Each PR requires two reviews from our team members

### Approved
- Once the pull request is approved by two reviewers, merge it
- Delete the branch

### Request changes
- Read suggested changes
- Discuss changes if neccessary
- Resolve conversation
- Request another review

## How to review
- When possible, create inline comments to change code
