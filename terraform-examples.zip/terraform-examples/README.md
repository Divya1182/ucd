**Looking for information on Terraform Modules? Scroll to the <a href="#terraform-modules">bottom</a>**


# Terraform Examples

This repository is a container for Terraform examples for deploying various AWS and Azure resources. Generally, these examples outline common patterns and best practices for resources that are too small or simple to create a [Terraform Module](https://www.terraform.io/docs/language/modules/index.html). Complex resources or sets of resources will be placed into a module which each live in their own repository with their own set of examples. See the "Terraform Modules" <a href="#terraform-modules">section below</a> for more info.

All of the examples in the main branch of this repo have been reviewed and should be treated as best practice. That does not mean, however, that the list is comprehensive and you may not find an example that fits your use case. If that's the case, reach out to someone from the Terraform community for guidance.

## How to Use

It's not possible to reference these examples from your application's Terraform code. They are just standalone snippets that highlight a use case or pattern. Use them only as guidance for creating the resources in your application.

## Contributing

Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on our code of conduct, and the process for submitting pull requests to us.

## Terraform Modules

If your use case is complex or large, then it might warrant a new Terraform Module. See our [Terraform Module Standards](https://confluence.sys.cigna.com/pages/viewpage.action?spaceKey=CLOUD&title=Terraform+Module+Standards) doc to determine if you should write a new module and how to do so.

[List of existing AWS Terraform Modules](https://github.sys.cigna.com/search?q=topic%3Aterraform-community+topic%3Aaws+org%3Acigna&type=Repositories)<br>
[List of existing Azure Terraform Modules](https://github.sys.cigna.com/search?q=topic%3Aterraform-community+topic%3Aazure+org%3Acigna&type=Repositories)
