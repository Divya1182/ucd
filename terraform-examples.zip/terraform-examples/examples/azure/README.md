# Terraform Examples

This folder is for Azure-specific Terraform examples like Azure resource creation, Azure data sources, the Azure provider, etc.