# Terraform Examples

This folder is for cloud-agnostic Terraform examples like manipulating variables, using Terraform functions, using dynamic patterns, etc.