# Documentdb-cluster
Example terraform stack to provision a DocumentDB cluster on AWS

**Requirements**
    
    terraform >= 0.13.0
    aws >= 2.0

**Providers**

    aws >= 2.0

**Testing**

This repository should serve as an example of how to setup DocumentDb. In this example, the following variables are initialized, however they will need to be configured for your particular use-case.

**Example Variable values**
(tags not included!)
```
enabled = true
region = "eu-central-1" #your region code
availability_zones = ["eu-central-1a", "eu-central-1b"] #AZs as per region
namespace = "eg"
stage = "test"
name = "documentdb-cluster"
vpc_cidr_block = "172.16.0.0/16" #your VPC CIDR
instance_class = "db.t3.medium"
cluster_size = 1
db_port = 27017
master_username = "docdbadmin"
master_password = "secretpassword"
retention_period = 7
preferred_backup_window = "05:00-07:00"
cluster_family = "docdb3.6"
engine = "docdb"
storage_encrypted = true
skip_final_snapshot = true
apply_immediately = true
```

