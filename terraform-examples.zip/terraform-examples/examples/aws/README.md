# Terraform Examples

This folder is for AWS-specific Terraform examples like AWS resource creation, AWS data sources, the AWS provider, etc.