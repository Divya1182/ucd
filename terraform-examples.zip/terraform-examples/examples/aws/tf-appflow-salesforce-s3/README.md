# Amazon AppFlow
Amazon AppFlow is a fully-managed integration service that enables you to securely exchange data between software as a service (SaaS) applications, such as Salesforce, and AWS services, such as Amazon Simple Storage Service (Amazon S3) and Amazon Redshift. For example, you can ingest contact records from Salesforce to Amazon Redshift or pull support tickets from Zendesk to an Amazon S3 bucket.


This module can be used to create AppFlow Control that can move your data from Salesforce to S3 or vice-versa.

To leverage this solution, you need to provide the variables defined below. The required variables need to be provided to successfully deploy it.


## Salesforce Connector
The Salesforce Connector will be created in your account with Connection Mode as ```Public``` or ```Private```. To create connector, you to complete some pre-requisite steps.
### Pre-requisites
* Co-ordinate with Salesforce team to create a Connected App in Salesforce. You can follow [this](https://help.salesforce.com/s/articleView?id=sf.connected_app_client_credentials_setup.htm&type=5) document for reference.
* Get the Consumer ID (clientID) and Consumer Secret (clientSecret) from the Salesforce team.
* Add project_name in tfvars. Run the module in the ```pre-requisites``` folder, it will create an empty secret in your account. The secret name will be in the outputs.
* Update the secret with the above clientID and clientSecret as -
  * ```clientId```: [CLIENT_ID]
  * ```clientSecret```: [CLIENT_SECRET]
* Note the name of the secret.

### Deployment
1. Go the examples folder, choose your requirement to deploy flow for (cd ../examples)
      * ```salesforce_to_s3```
      * ```s3_to_salesforce```
2. Go the respective folder, update the variables, and try to deploy it. Use the following required variables
   * ```project_name``` - Your Project Name
   * ```flow_type``` - Valid values are ```salesforce_to_s3``` or ```s3_to_salesforce```
   * ```salesforce_instance_url``` -  salesforce URL
   * ```salesforce_client_secret_name``` - Salesforce secretmanager secret (from pre-requisites step)
   * ```provide_existing_s3_bucket``` - If you are going to provide existing bucket, please specify ```true```. If you want the automation to create it, pass in ```false```. If set to ```true```, look [here](#providing-existing-bucket) for bucket policy.
   * ```appflow_s3_bucket_name``` - If provide_existing_s3_bucket is set to true, this name will be used for your data in the S3 bucket. If provide_existing_s3_bucket is set to true, S3 bucket will be created where you want to store your data, the bucket name will be [project_name]-[account_id]-[appflow_s3_bucket_name]
   * ```s3_object_prefix_name``` - Path to your object in S3
   * ```salesforce_object_name``` - Salesforce object name you want to capture
   * ```salesforce_auth_code``` - Pass in Salesforce authcode. You can refer [this](#salesforce-auth-code) section for generating one
   * ```trigger_type``` - Valid values are OnDemand and Event
   * ```required_tags``` - Required tags for your resources
   * ```required_data_tags``` - Required data tags for S3 bucket
4. There are other variables defined below that you can refer to customize your solution

NOTE - for ```s3_to_salesforce``` flow, you would need to pass in an S3 bucket name which exists and has the data that you want to transfer to Salesforce


### Salesforce Auth Code
You can retrieve the Salesforce Authorization code by doing the following -
1. In a browser, go to this URL after you substitute the placeholder values. ```https://your_site_url/services/oauth2/authorize?response_type=code&client_id=your_client_id&​redirect_uri=your_url_encoded_redirect_uri```
2. Log in and approve your app.
3. When you receive a callback, you will get the authorization code in your browser URL.

### Providing Existing Bucket

When you are providing an existing bucket name, make sure you have appropriate bucket policy applied to it. Check below for the instructions -
* Bucket Policy for moving data from Salesforce to S3 -
```{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "Statement1",
            "Effect": "Allow",
            "Principal": {
                "Service": "appflow.amazonaws.com"
            },
            "Action": [
                "s3:PutObject",
                "s3:AbortMultipartUpload",
                "s3:ListMultipartUploadParts",
                "s3:ListBucketMultipartUploads",
                "s3:GetBucketAcl",
                "s3:PutObjectAcl"
            ],
            "Resource": [
                "arn:aws:s3:::{BUCKET_NAME}",
                "arn:aws:s3:::{BUCKET_NAME}/*"
            ]
        }
    ]
}

```

* Bucket Policy for moving data from S3 to Salesforce -
```{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "Statement1",
            "Effect": "Allow",
            "Principal": {
                "Service": "appflow.amazonaws.com"
            },
            "Action": [
                "s3:ListBucket",
                "s3:GetObject"
            ],
            "Resource": [
                "arn:aws:s3:::{BUCKET_NAME}",
                "arn:aws:s3:::{BUCKET_NAME}/*"
            ]
        }
    ]
}

```

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.61.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_s3"></a> [s3](#module\_s3) | git::https://github.sys.cigna.com/cigna/terraform-aws-s3 | 7.0.5 |

## Resources

| Name | Type |
|------|------|
| [aws_appflow_connector_profile.salesforce-connector](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/appflow_connector_profile) | resource |
| [aws_appflow_flow.appflow_control_flow_s3_to_salesforce](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/appflow_flow) | resource |
| [aws_appflow_flow.appflow_control_flow_salesforce_to_s3](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/appflow_flow) | resource |
| [aws_cloudwatch_metric_alarm.appflow_flow_failed_execution](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_metric_alarm) | resource |
| [aws_kms_alias.appflow_kms_alias](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/kms_alias) | resource |
| [aws_kms_key.appflow_kms](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/kms_key) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_policy_document.destination_bucket_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [aws_secretsmanager_secret.salesforce_secret](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_appflow_control_flow_name_s3_to_salesforce"></a> [appflow\_control\_flow\_name\_s3\_to\_salesforce](#input\_appflow\_control\_flow\_name\_s3\_to\_salesforce) | AppFlow Control Flow Name for S3 to Salesforce Data Flow | `string` | `"appflow_control_flow_s3_to_salesforce"` | no |
| <a name="input_appflow_control_flow_name_salesforce_to_s3"></a> [appflow\_control\_flow\_name\_salesforce\_to\_s3](#input\_appflow\_control\_flow\_name\_salesforce\_to\_s3) | AppFlow Control Flow Name for Saleforce to S3 Data Flow | `string` | `"appflow_control_flow_salesforce_to_s3"` | no |
| <a name="input_appflow_flow_execution_failed_alarm_description"></a> [appflow\_flow\_execution\_failed\_alarm\_description](#input\_appflow\_flow\_execution\_failed\_alarm\_description) | Description for AppFlow Execution Failed Alarm. If you are planning to use Alarm Funnel for alerting and Notification<br>make sure you provide the description in correct format. E.g "Environment \| Log Level \| App Name \| Alarm Description" | `string` | `"dev | INFO | Project-Name | AppFlow Flow Execution Failed"` | no |
| <a name="input_appflow_flow_failed_execution_alarm"></a> [appflow\_flow\_failed\_execution\_alarm](#input\_appflow\_flow\_failed\_execution\_alarm) | AppFlow Execution Failed Alarm Name | `string` | `"appflow-execution-failed-alarm"` | no |
| <a name="input_appflow_kms_key_name"></a> [appflow\_kms\_key\_name](#input\_appflow\_kms\_key\_name) | AppFlow KMS Key Name | `string` | `"alias/appflow-kms-key"` | no |
| <a name="input_appflow_s3_bucket_name"></a> [appflow\_s3\_bucket\_name](#input\_appflow\_s3\_bucket\_name) | AppFlow S3 bucket Name | `string` | n/a | yes |
| <a name="input_connection_mode"></a> [connection\_mode](#input\_connection\_mode) | Salesforce Connection Mode | `string` | `"Public"` | no |
| <a name="input_existing_salesforce_connector_name"></a> [existing\_salesforce\_connector\_name](#input\_existing\_salesforce\_connector\_name) | Are you providing any existing Salesforce Connector? If yes, this variable needs to be have the<br>existing Salesforce Connector Name | `string` | `"salesforce-connector"` | no |
| <a name="input_flow_type"></a> [flow\_type](#input\_flow\_type) | Control Flow type. It must be s3\_to\_salesforce or salesforce\_to\_s3 | `string` | `"salesforce_to_s3"` | no |
| <a name="input_is_salesforce_sandbox_environment"></a> [is\_salesforce\_sandbox\_environment](#input\_is\_salesforce\_sandbox\_environment) | Is Salesforce a Sandbox environment | `bool` | `false` | no |
| <a name="input_mapped_all_fields"></a> [mapped\_all\_fields](#input\_mapped\_all\_fields) | This variable is set to map all the fields automatically. If you want to set mapping for specific fields,<br>then set it to false, and provide the mapping in the variable mapping\_fields | `bool` | `true` | no |
| <a name="input_mapping_fields"></a> [mapping\_fields](#input\_mapping\_fields) | This variable is used to provide the mapping of the fields. If you set mapped\_all\_fields to false,<br>then set this variable as follows -<br>{<br>    "source\_field\_name1": "destination\_field\_name1",<br>    "source\_field\_name2": "destination\_field\_name2",<br>    ....<br>} | `map(string)` | `{}` | no |
| <a name="input_passing_existing_salesforce_connector"></a> [passing\_existing\_salesforce\_connector](#input\_passing\_existing\_salesforce\_connector) | Are you providing any existing Salesforce Connector? If yes, this variable needs to be set to true, and provide the<br>existing Salesforce Connector Name in the variable existing\_salesforce\_connector\_name | `bool` | `false` | no |
| <a name="input_project_name"></a> [project\_name](#input\_project\_name) | Name of your project | `string` | n/a | yes |
| <a name="input_provide_existing_s3_bucket"></a> [provide\_existing\_s3\_bucket](#input\_provide\_existing\_s3\_bucket) | Are you providing your existing S3 bucket? For moving data S3 to Salesforce, you need to provide your own S3 bucket.<br>This needs to be set to true for that. | `bool` | n/a | yes |
| <a name="input_required_data_tags"></a> [required\_data\_tags](#input\_required\_data\_tags) | Required tags for data at rest as defined by the CCOE Cloud Tagging Requirements | <pre>object({<br>    BusinessEntity         = string<br>    ComplianceDataCategory = string<br>    DataClassification     = string<br>    DataSubjectArea        = string<br>    LineOfBusiness         = string<br>  })</pre> | n/a | yes |
| <a name="input_required_tags"></a> [required\_tags](#input\_required\_tags) | Required common resource tags as defined by the CCOE Cloud Tagging Requirements | <pre>object({<br>    AssetOwner       = string<br>    CostCenter       = string<br>    SecurityReviewID = string<br>    ServiceNowAS     = string<br>    ServiceNowBA     = string<br>    AppName          = string<br>  })</pre> | n/a | yes |
| <a name="input_s3_object_prefix_name"></a> [s3\_object\_prefix\_name](#input\_s3\_object\_prefix\_name) | S3 Object Prefix Name | `string` | `"PATH"` | no |
| <a name="input_s3_to_salesforce_s3_bucket_prefix"></a> [s3\_to\_salesforce\_s3\_bucket\_prefix](#input\_s3\_to\_salesforce\_s3\_bucket\_prefix) | S3 Bucket Prefix for Control Flow with data flowing from S3 to Salesforce | `string` | `""` | no |
| <a name="input_s3_to_salesforce_s3_input_file_type"></a> [s3\_to\_salesforce\_s3\_input\_file\_type](#input\_s3\_to\_salesforce\_s3\_input\_file\_type) | S3 Input File type. Supported CSV or JSON | `string` | `"CSV"` | no |
| <a name="input_salesforce_auth_code"></a> [salesforce\_auth\_code](#input\_salesforce\_auth\_code) | Salesforce Authcode | `string` | n/a | yes |
| <a name="input_salesforce_client_secret_name"></a> [salesforce\_client\_secret\_name](#input\_salesforce\_client\_secret\_name) | Salesforce client\_id and client\_secret Secretsmanager secret name | `string` | n/a | yes |
| <a name="input_salesforce_connector_profile_name"></a> [salesforce\_connector\_profile\_name](#input\_salesforce\_connector\_profile\_name) | Salesforce Connector Profile Name | `string` | `"salesforce-connector"` | no |
| <a name="input_salesforce_instance_url"></a> [salesforce\_instance\_url](#input\_salesforce\_instance\_url) | Salesforce Instance URL | `string` | n/a | yes |
| <a name="input_salesforce_object_name"></a> [salesforce\_object\_name](#input\_salesforce\_object\_name) | Salesforce Object Name | `string` | n/a | yes |
| <a name="input_salesforce_redirect_uri"></a> [salesforce\_redirect\_uri](#input\_salesforce\_redirect\_uri) | Salesforce Redirect URI | `string` | `"https://login.salesforce.com/"` | no |
| <a name="input_trigger_type"></a> [trigger\_type](#input\_trigger\_type) | Flow Trigger Type | `string` | `"OnDemand"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_kms_key_alias_name"></a> [kms\_key\_alias\_name](#output\_kms\_key\_alias\_name) | AppFlow KMS Key Alias |
<!-- END_TF_DOCS -->