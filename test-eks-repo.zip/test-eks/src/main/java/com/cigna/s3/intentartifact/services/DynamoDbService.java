package com.cigna.s3.intentartifact.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;
import software.amazon.awssdk.services.dynamodb.model.GetItemResponse;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Service
public class DynamoDbService {
    private final Logger logger = LoggerFactory.getLogger(DynamoDbService.class);

    @Value("${aws.dynamodb.table.name}")
    private String tableName;

    public DynamoDbService(){}

    public Map<String, String> getItemById(String id) {

        logger.info("DYNAMO TABLE NAME: " + tableName);
        Map<String, AttributeValue> key = new HashMap<>();
        key.put("document_id", AttributeValue.builder().s(id).build());  // assuming partition key is 'id' and type is String

        GetItemRequest request = GetItemRequest.builder()
                .tableName(tableName)
                .key(key)
                .build();

        try {
            DynamoDbClient dynamoDbClient = DynamoDbClient.builder()
                    .region(Region.of(System.getenv("AWS_REGION")))
                    .credentialsProvider(DefaultCredentialsProvider.create())
                    .build();

            GetItemResponse response = dynamoDbClient.getItem(request);
            if (response.hasItem()) {
                Map<String, AttributeValue> returnedItem = response.item();
                Map<String, String> response_map = new HashMap<>();
                Set<String> keys = returnedItem.keySet();
                for (String item_key : keys) {
                    String value = returnedItem.get(item_key).toString();
                    response_map.put(item_key, value);
                    logger.info("Item found: %s : %s", item_key, value);
                }
                return response_map;
            } else {
                logger.info("Item not found with id: " + id);
                return Collections.emptyMap();
            }
        } catch (DynamoDbException e) {
            logger.error("Error fetching item from DynamoDB: ", e);
            e.printStackTrace();
            throw e;
        }
    }
}
