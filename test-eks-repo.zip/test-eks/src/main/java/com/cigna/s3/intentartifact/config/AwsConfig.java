//package com.cigna.s3.intentartifact.config;
//
//import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//
//    @Configuration
//    public class AwsConfig {
//
//        @Bean(name="entityManagerFactory")
//        public LocalSessionFactoryBean sessionFactory() {
//            LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
//            return sessionFactory;
//        }
//    }
